import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

//import java.util.Observer;

import javafx.application.Platform;
import javafx.scene.control.ListView;


public class Server extends ServerRPSLS{
	int clientcount = 1;
	int numConnected = 0;
	int portNumber = ServerRPSLS.portNum;
	ArrayList<ClientThread> clients = new ArrayList<ClientThread>();
	TheServer server;
	private Consumer<Serializable> callback;
	
	ServerSubject MySubject = new ServerSubject();
	ArrayList<String> playersInGame = new ArrayList<String>(); // Keeps track of all players inGame
	ArrayList<GameInfo> onGoingGames = new ArrayList<GameInfo>(); //list of ongoing games
	int gameCount = 0; // Keeps track game number

	
	private final Object lock= new Object(); // An object for syncronization
	
	// Keeps track of the the two players competing
	String initiator = new String();
	String opponent = new String();
	
	// Keeps track of position of players in client list from observer list
	int initiatorPos = 0;
	int opponentPos = 0;
	
	GameInfo gameData = new GameInfo();
	
	
	Server(Consumer<Serializable> call){
		callback = call;
		server = new TheServer();
		server.start();
	}
	
	
	
	
		public class TheServer extends Thread{
			public void run() {
				
				try(ServerSocket mysocket = new ServerSocket(portNumber);){
					System.out.println("Server is waiting for a client!");
					callback.accept("Server is waiting for players!");
					
					while(true) {
						
						
						ClientThread c = new ClientThread(mysocket.accept(), clientcount);
						callback.accept("Player has connected to server: " + "Player #" + clientcount);
						clients.add(c);
						c.start();
						
						SubscriberObserver ob = new SubscriberObserver(clientcount);
						MySubject.register(ob);
						
						/*
						for(int i = 0; i < MySubject.observers.size(); i++) {
					 		System.out.println(MySubject.observers.get(i).playerString);
						}
						 */
						
						clientcount++;
						numConnected++; // Updates Number of connections connected
						numConnectionsTextField.setText(String.valueOf(numConnected));
		
					}//end of while
				}//end of try
				catch(Exception e) {
					callback.accept("Server socket did not launch");
				}
			} // end of run
		} // end of TheServer
		
		
		public class ClientThread extends Thread{
			Socket connection;
			int count;
			ObjectInputStream in;
			ObjectOutputStream out;
			String winner;			
			
			// Default Constructor
			ClientThread(Socket s, int count){
				this.connection = s;
				this.count = count;	
			}
			
			public void updateClients(GameInfo data) {
				for(int i = 0; i < clients.size(); i++) {
					ClientThread t = clients.get(i);
					try {
					 t.out.writeUnshared(data);
					}
					catch(Exception e) {}
				}
			}
			
			public void run(){
				try {
					in = new ObjectInputStream(connection.getInputStream());
					out = new ObjectOutputStream(connection.getOutputStream());
					connection.setTcpNoDelay(true);
					
					out.writeUnshared((Integer) count); // send them which player they are
					//MySubject.notifyObservers(); // Send them all clients a list of players connected
					
				}
				catch(Exception e) {
					System.out.println("Streams not open");
				}
				
					
				 while(true) {
					    try {
					    	
						   		Object o = in.readUnshared(); // Generic Object
						   		
						   		synchronized(lock){
						   			
							   		
							    	// If object read is a string
							    	if(o instanceof String) {
							    		// If object contains "Play Against", then a player wants to start a game
							    		if(o.equals("Play Against")) {
							    			//synchronized(lock) {
								    			initiator = (String) in.readUnshared(); // Get the person who initiated the game
								    			opponent = (String) in.readUnshared(); // Get who the initiator wants to challenge
								    			
								    			// Find position of players in client thread list
								    			for(int i = 0; i < MySubject.observers.size(); i++) {
								    				if(MySubject.observers.get(i).playerString.equals(initiator)) {
								    					initiatorPos = i;
								    				}
								    				if(MySubject.observers.get(i).playerString.equals(opponent)) {
								    					opponentPos = i;
								    				}
								    			}
								    			
								    			// If opponent is in game, send a message back to the person who initiated the game
								    			if(findInGame(opponent) != -1) {
								    				clients.get(initiatorPos).out.writeUnshared("Opponent In Game"); // Send to initiator the message and dont start the game
								    			}
								    			// Else send a message to opponent if they want to play a game or not
								    			else {
								    				clients.get(initiatorPos).out.writeUnshared("Waiting For " + opponent + " Response");
								    				clients.get(opponentPos).out.writeUnshared(initiator + " Wants To Challenge You"); // Send to player two that player one wants a challenge
								    				clients.get(opponentPos).out.writeUnshared(initiator); // Send to opponent initiator player number
								    			}
							    			//}
							    			
							    		} // End of "Play Against
							    		
							    		// If object contains string "Challenge Accepted
							    		else if(o.equals("Challenge Accepted")) {
							    			//synchronized(lock) {
								    			initiator = (String) in.readUnshared();
								    			opponent = (String) in.readUnshared();
								    			
								    			// Add both players to playerInGame list
							    				playersInGame.add(initiator); 
							    				playersInGame.add(opponent);
							    		
							                    gameCount++; // Increment Game Number Session
							                    
							                    GameInfo temp = new GameInfo(); // Create a temporary GameInfo
							                    temp.game = gameCount; // Add game number to temporary GameInfo
							                    onGoingGames.add(temp); // Add it to list of onGoingGames
							                    
							                    
							                    // Find position of players in client thread list
						    					initiatorPos = findPlayerPos(initiator);
						    					opponentPos = findPlayerPos(opponent);
				
								    				
							                    
							                    // Update temp GameInfo to player one data and send it player one client
							                    temp.whoAmI = 1;
							                    temp.initiator = initiator;
							                    temp.opponent = opponent;
							                    temp.whichPlayer = initiator;
							                    clients.get(initiatorPos).out.writeUnshared((GameInfo) temp); 
							                    
							                    // Update temp GameInfo to player two data and send it player one client
							                    temp.whoAmI = 2;
							                    temp.whichPlayer = opponent;
							                    clients.get(opponentPos).out.writeUnshared((GameInfo) temp); 
							    			//}
							    		
							    		} // End of "Challenge Accepted"
							    		
							    		else if(o.equals("Challenge Declined")) {
							    			//synchronized(lock) {
								    			initiator = (String) in.readUnshared();
								    			
								    			clients.get(findPlayerPos(initiator)).out.writeUnshared("Opponent Declined Game"); // Send to initiator to opponent Decline game
							    			//}
							    		}// End of "Challenge Declined'
							    		else if(((String) o).contains("Has A Pending Invitation")) {
							    			initiator = (String) in.readUnshared();
							    			clients.get(findPlayerPos(initiator)).out.writeUnshared((String) o); // Send to player one to opponent Decline game
							    		}
							    		
							    		// If a player chooses to play again send them a list of players connected
							    		else if(o.equals("Get Players Connected List")) {
							    			MySubject.notifyObservers(); // Send them all clients a list of players connected
							    		} // End of "Play Again"
							    		
							    	} // End of if statement when o is a string
							    	
							    	// If object read is a GameInfo type
							    	else if(o instanceof GameInfo) {
							    		//synchronized(lock) {
								    		GameInfo tempGameInfo = (GameInfo) o;
								    		int gamePos = findGamePos(tempGameInfo.game);
								    		
								    		if(gamePos != -1) {
									    		onGoingGames.get(gamePos).initiator = tempGameInfo.initiator;
									    		onGoingGames.get(gamePos).opponent = tempGameInfo.opponent;
									    		
									    		
									    		//check if p1 has played 
								                if (!tempGameInfo.initiatorPlays.equals("NULL")) {
								                    initiator = tempGameInfo.whichPlayer;
								                    onGoingGames.get(gamePos).initiatorPlays = tempGameInfo.initiatorPlays;
													callback.accept(initiator + " chose " + onGoingGames.get(gamePos).initiatorPlays); // Update server listview what each player chose
								                }
								                //check if p2 has played 
								                else if (!tempGameInfo.opponentPlays.equals("NULL")) {
								                    opponent = tempGameInfo.whichPlayer;
								                    onGoingGames.get(gamePos).opponentPlays = tempGameInfo.opponentPlays;
													callback.accept(opponent + " chose " + onGoingGames.get(gamePos).opponentPlays); // Update server listview what each player chose
								                }
								                
								                // If both players haven chosen a fighter, check who won
								                if (!onGoingGames.get(gamePos).initiatorPlays.equals("NULL") && !onGoingGames.get(gamePos).opponentPlays.equals("NULL")) {
								                    winner = whoWon(onGoingGames.get(gamePos).initiatorPlays, onGoingGames.get(gamePos).opponentPlays);
								                  
								                    
								                    if(winner.equals("P1")) {
								                    	onGoingGames.get(gamePos).roundWon = onGoingGames.get(gamePos).initiator + " Won The Round!";
								                    	callback.accept(onGoingGames.get(gamePos).roundWon);
								                
													}
													else if (winner.equals("P2")) {												
														onGoingGames.get(gamePos).roundWon = onGoingGames.get(gamePos).opponent + " Won The Round!";
														callback.accept(onGoingGames.get(gamePos).roundWon);
								                    }
													else {
														onGoingGames.get(gamePos).roundWon = "Round Is A Tie!";  
														callback.accept(onGoingGames.get(gamePos).roundWon);
								                    }
								                   
								                    
								                    // Find position of players in client thread list
													initiatorPos = findPlayerPos(onGoingGames.get(gamePos).initiator);
								                    opponentPos = findPlayerPos(onGoingGames.get(gamePos).opponent);
				
								                    
				
								                    //send each client the gamedata containing round won;
								                    onGoingGames.get(gamePos).whoAmI = 1; // Reset who am I
								                    clients.get(initiatorPos).out.writeUnshared((GameInfo) onGoingGames.get(gamePos));
								                    onGoingGames.get(gamePos).whoAmI = 2; // Reset who am I
								                    clients.get(opponentPos).out.writeUnshared((GameInfo) onGoingGames.get(gamePos));
								                    
								                    
								                    
								                    // Delete game from onGoingGames
								                    onGoingGames.remove(gamePos);
								                    
								                    // Delete players from inGame list
								                    //playersInGame.remove(findInGame(onGoingGames.get(gamePos).initiator));
								                    //playersInGame.remove(findInGame(onGoingGames.get(gamePos).opponent));
								                 }
								    		} // End of IF gamePos != -1
								    		// If gamePos is -1, then delete player from inGame list
								    		else {
								    			playersInGame.remove(findInGame(tempGameInfo.whichPlayer));
								    		}
							    		} 	
						   		} // End of synchro
						    } // End of try
						    catch(Exception e) {
						    	synchronized(lock) {
							    	//gameData.message = "Player "+count+" has left the server!";
							    	callback.accept("OOOOPPs...Something wrong with the socket from player: " + count + "....closing down!");
							    	 
							    	int pos = 0; // Keeps track of position of observer in the list
							    	
							    	for(int i = 0; i < MySubject.observers.size(); i++) {
							    		if(MySubject.observers.get(i).player == count) {
							    			pos = i; // Updates position
							    		}
							    	}
							    	
							    	// If player is inGame and gets disconnected remove them from inGame list
							    	if(findInGame(MySubject.observers.get(pos).playerString) != -1) {
							    		playersInGame.remove(findInGame(MySubject.observers.get(pos).playerString));
							    	}
							    	
							    	MySubject.unregister(MySubject.observers.get(pos)); // Remove player from observers list
							    	MySubject.notifyObservers(); // Notify all players updated list
							    	
							    	clients.remove(this);
							    	numConnected--; 
							    	
							    	numConnectionsTextField.setText(String.valueOf(numConnected));
							    	
							    	break;
						    	} // End of synchronized
						    } // End of catch
					} // end of while
				 
				}//end of run
			
		}//end of client thread
		
		public class ServerSubject{

		    public ArrayList<SubscriberObserver> observers;
			private final Object MUTEX= new Object();
			
			public ServerSubject(){
				this.observers=new ArrayList<>();
			}

			
			public void register(SubscriberObserver obj) {
				if(obj == null) throw new NullPointerException("Null Observer");
				
				synchronized (MUTEX) {
					if(!observers.contains(obj)) {
						observers.add((SubscriberObserver) obj);
					}
				}
			}

			
			public void unregister(SubscriberObserver obj) {
				synchronized (MUTEX) {
					observers.remove(obj);
				}
			}

			
			public void notifyObservers() {
				ArrayList<SubscriberObserver> observersLocal = null;
				//synchronization is used to make sure any observer registered after message is received is not notified
				synchronized (MUTEX) {
					observersLocal = new ArrayList<SubscriberObserver>(this.observers);
					
					ArrayList<String> playerList = new ArrayList<String>(); // Create a ArrayList of strings  containing all players connected to the server
					
					for(int i = 0; i < observers.size(); i++) {
						playerList.add(observers.get(i).playerString); // Add strings to playList
						
					}
				
					for (SubscriberObserver obj : observersLocal) {
						obj.update(observers); // update observer array list for each observer
						
						try {
							int pos = 0; // Keeps track of position of observer in the client list
					    	
					    	for(int i = 0; i < clients.size(); i++) {
					    		if(clients.get(i).count == obj.player) {
					    			pos = i; // Updates position
					    		}
					    	}
					
							clients.get(pos).out.writeUnshared((ArrayList<String>) playerList); // Write observer list to specific player
							
						} // end of try
						catch (IOException e) {
							e.printStackTrace();
						} // end of catch
						
					} // end of for loop
				} // End of syncronize
			}// end of notifyObservers()
		}
		
		
		public class SubscriberObserver implements Serializable{
			ArrayList<SubscriberObserver> observers; 
			int player; // Keeps track of what player the observer is
			String playerString;
	
			SubscriberObserver(int count){
				this.observers = new ArrayList<SubscriberObserver>();
				this.player = count;
				this.playerString = "Player " + this.player;
				
			}
			
			
			public void update(ArrayList<SubscriberObserver> newObserverList) {
				this.observers = newObserverList;
				
			}
		}


		
		//returns the index of the player in clientThread List
		public int findPlayerPos(String player) {
	        // Find position of players in client thread list
	        for(int i = 0; i < MySubject.observers.size(); i++) {
	          if(MySubject.observers.get(i).playerString.equals(player)) {
	            return i; // Return position
	          }
	        }
	        return -1; // Return -1 if not found, error
	      }
		
		//returns the index of the GameNumber in OngoingGame List
	    public int findGamePos(int gameNumber) {
	        for (int i = 0; i < onGoingGames.size(); ++i) {
	          if (onGoingGames.get(i).game == gameNumber) {
	            return i; // Return position
	          }
	        }
	        return -1; // Return -1 if not found, error
	    }
	      
	      
		// Function that checks if opponent is in game
		int findInGame(String opponent) {
			// Traverses the list of players in game and if found the return true, else false
			for(int i = 0; i < playersInGame.size(); i++) {
				if(playersInGame.get(i).equals(opponent)) {
					return i;
				}
			}
			return -1;
		}
		
	  //determines which player won each round
	  static public String whoWon(String playsP1, String playsP2 ) {
		  switch (playsP1) {
	      case "scissor":
			if ((playsP2.equals("paper")) || (playsP2.equals("lizard"))) {
			  return "P1";
			}
			else if ((playsP2.equals("spock")) || (playsP2.equals("rock"))) {
			  return "P2";
			}
			else {
			  return "tie";
			    }
			  case "paper":
			if ((playsP2.equals("rock")) || (playsP2.equals("spock"))) {
			  return "P1";
			}
			else if ((playsP2.equals("scissor")) || (playsP2.equals("lizard"))) {
			  return "P2";
			}
			else {
			  return "tie";
			    }
			  case "lizard":
			if ((playsP2.equals("paper")) || (playsP2.equals("spock"))) {
			  return "P1";
			}
			else if ((playsP2.equals("scissor")) || (playsP2.equals("rock"))) {
			  return "P2";
			}
			else {
			  return "tie";
			    }
			  case "spock":
			if ((playsP2.equals("rock")) || (playsP2.equals("scissor"))) {
			  return "P1";
			}
			else if ((playsP2.equals("lizard")) || (playsP2.equals("paper"))) {
			  return "P2";
			}
			else {
			  return "tie";
			    }
			  case "rock":
			if ((playsP2.equals("lizard")) || (playsP2.equals("scissor"))) {
			  return "P1";
			}
			else if ((playsP2.equals("spock")) || (playsP2.equals("paper"))) {
			  return "P2";
			}
			else {
			  return "tie";
			}
		    default:
		      return "NULL";
		    }
	   } // End of whoWon
	 
}
