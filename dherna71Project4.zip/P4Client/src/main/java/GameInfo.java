import java.io.Serializable;
import java.util.ArrayList;

import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class GameInfo implements  Serializable{
  String initiatorPlays;
  String opponentPlays;
  String roundWon; 
  int whoAmI; // Whether you are initiator or opponent
  String initiator; // Stores the player number for initiator
  String opponent; // Stores the player number for opponent
  String whichPlayer; // You're actual player number
  int game; // Which game sesssion
  

  // Default constructor
  GameInfo() {
    this.initiatorPlays = "NULL";
    this.opponentPlays = "NULL";
    this.roundWon = "NULL";
    this.whoAmI = -1;
    this.initiator = "NULL";
    this.whichPlayer = "NULL";
    this.game = -1;
    
  }

 
}