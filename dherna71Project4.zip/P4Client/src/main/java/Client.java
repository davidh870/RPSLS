import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.ArrayList;
import java.util.function.Consumer;

import javafx.application.Platform;


public class Client extends Thread{
	public GameInfo gameData = new GameInfo(); // Keeps track of game
	public String initiator = new String(); // Keeps track of which opponent initiated a game
	
	Socket socketClient;
	
	ObjectOutputStream out;
	ObjectInputStream in;
	
	int portnum;
	String ipaddress;
	
	// Add a observer array list 
	
	private Consumer<Serializable> clientcallback;
	private Consumer<Serializable> messagecallback;
	
	Client(Consumer<Serializable> newclientCall, Consumer<Serializable> newmessageCall){
	
		clientcallback = newclientCall;
		messagecallback = newmessageCall; 
		portnum = ClientRPSLS.portNum;
		ipaddress = ClientRPSLS.ipAddress;
	}
	
	public void run() {	
		
		try {
		socketClient= new Socket(ipaddress,portnum);
	    out = new ObjectOutputStream(socketClient.getOutputStream());
	    in = new ObjectInputStream(socketClient.getInputStream());
	    socketClient.setTcpNoDelay(true);
		}
		catch(Exception e) {}
		
		while(true) {
			 
			try {
				
				 
				Object o = in.readUnshared(); // Generic Object Read
				ArrayList<String> playerList = new ArrayList<String>();
				
				// If Object is an Integer, Let the client know which player they are
				if(o instanceof Integer) {
					ClientRPSLS.whichPlayer = (Integer) o;
				}
				// If Object is an ArrayList, Update Clients List that are connected 
				else if(o instanceof ArrayList<?> ) {
					// Clear Client list
					Platform.runLater(()->{ClientRPSLS.clientList.getItems().clear();
										  });
					
					playerList =  (ArrayList<String>) o; // update player List
					
					// Callback all strings to client List view
					for(int i = 0; i < playerList.size(); i++) {
						clientcallback.accept(playerList.get(i));
					}
					
				}
				// If object is a string
				else if(o instanceof String) {
					String temp = (String) o;
					// If object string is "Waiting For Opponent's Response", Send message to message board
					if(((String) o).contains("Waiting For")) {
						messagecallback.accept((String) o);
					}
					// If object string is "Opponent In Game", Send message to message board and don't start game
					else if(o.equals("Opponent In Game")) {
						messagecallback.accept((String) o);
						
						Platform.runLater(()->{ ClientRPSLS.challengeButton.setDisable(false);
						});
					}
					// If Object string is "Opponent Declined Game", send message to message board and dont start game
					else if(((String) o).contains("Wants To Challenge You")) {
						if(initiator.isEmpty()) {
							initiator = (String) in.readUnshared(); // Get the opponent player number
							
							messagecallback.accept((String) o);
							
							// Enable accept and decline button
							Platform.runLater(()->{ClientRPSLS.acceptButton.setDisable(false);
												   ClientRPSLS.acceptButton.setVisible(true);
												   ClientRPSLS.declineButton.setDisable(false);
												   ClientRPSLS.declineButton.setVisible(true);
												   ClientRPSLS.challengeButton.setVisible(false);
												   ClientRPSLS.challengeButton.setDisable(true);
							  });
						}
						else {
							String tempInitiator = (String) in.readUnshared(); // Get the opponent player number
							out.writeUnshared((String) "Player " + ClientRPSLS.whichPlayer + " Has A Pending Invitation"); // Send message to server
							out.writeUnshared((String) tempInitiator); // Send server opponent player number	
						}
						
					}
					// If Object string is "Opponent Declined Game", send message to message board and dont start game
					else if(o.equals("Opponent Declined Game")) {
						messagecallback.accept((String) o);
						
						Platform.runLater(()->{ ClientRPSLS.challengeButton.setDisable(false);
						});
					}
					// If Object string contains "Has A Pending Invitation", send message to message board and dont start game
					else if(((String) o).contains("Has A Pending Invitation")) {
						messagecallback.accept((String) o);
						
						Platform.runLater(()->{ ClientRPSLS.challengeButton.setDisable(false);
						});
					}
					
				}
				else if(o instanceof GameInfo) {
					gameData = (GameInfo) o;
					ClientRPSLS.whoAmI = gameData.whoAmI;
					
					if(!gameData.roundWon.equals("NULL")) {
						
						Platform.runLater(()->{ 
											ClientRPSLS.window.setScene(ClientRPSLS.thirdSceneCreate());
											ClientRPSLS.winnerText.setText(gameData.roundWon);
											
											if(ClientRPSLS.whoAmI == 1) {
												if(gameData.opponentPlays.equals("rock")) {
													ClientRPSLS.opponentRock.setVisible(true);
												}
												else if(gameData.opponentPlays.equals("paper")) {
													ClientRPSLS.opponentPaper.setVisible(true);
												}
												else if(gameData.opponentPlays.equals("scissor")) {
													ClientRPSLS.opponentScissor.setVisible(true);
												}
												else if(gameData.opponentPlays.equals("lizard")) {
													ClientRPSLS.opponentLizard.setVisible(true);
												}
												else if(gameData.opponentPlays.equals("spock")) {
													ClientRPSLS.opponentSpock.setVisible(true);
												}
											}
											else if(ClientRPSLS.whoAmI == 2) {
												if(gameData.initiatorPlays.equals("rock")) {
													ClientRPSLS.opponentRock.setVisible(true);
												}
												else if(gameData.initiatorPlays.equals("paper")) {
													ClientRPSLS.opponentPaper.setVisible(true);
												}
												else if(gameData.initiatorPlays.equals("scissor")) {
													ClientRPSLS.opponentScissor.setVisible(true);
												}
												else if(gameData.initiatorPlays.equals("lizard")) {
													ClientRPSLS.opponentLizard.setVisible(true);
												}
												else if(gameData.initiatorPlays.equals("spock")) {
													ClientRPSLS.opponentSpock.setVisible(true);
												}
											}
											
											// Reset initiator
											initiator = new String();
						});
						
						
					}
					else {
						Platform.runLater(()->{ ClientRPSLS.window.setScene(ClientRPSLS.gameSceneCreate());
												ClientRPSLS.playerDisplay.setText("Player " + ClientRPSLS.whichPlayer);
						});
						
						 
					}
				}
				
				
				
			}
			catch(Exception e) {}
		}
	
    }
	
	public void send(GameInfo data) {
		
		try {
			out.writeUnshared(data);
			//out.reset();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public class SubscriberObserver implements Serializable{
		ArrayList<SubscriberObserver> observers;
		int player;
		String playerString;

		
		
		SubscriberObserver(int count){
			this.observers = new ArrayList<SubscriberObserver>();
			this.player = count;
			this.playerString = "Player " + this.player;
			
		}
		
		
		public void update(ArrayList<SubscriberObserver> newObserverList) {
			this.observers = newObserverList;
			
		}
	}
	
	
}
