import java.io.IOException;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ClientRPSLS extends Application {
	// Variables 
	static Stage window;
	
	// Game Points Text Field
	static TextField playerOnePointsDisplay;
	static TextField playerTwoPointsDisplay;
	// Buttons For Game
	static ImageView rockButton;
	static ImageView paperButton;
	static ImageView scissorButton;
	static ImageView lizardButton;
	static ImageView spockButton;
	static Button confirmButton;
	static Button acceptButton;
	static Button declineButton;
	static Button challengeButton;
	
	// Opponent fighter Image
	static ImageView opponentRock;
	static ImageView opponentPaper;
	static ImageView opponentScissor;
	static ImageView opponentLizard;
	static ImageView opponentSpock;
	
	// Connection Data
	static public Client clientConnection;
	static int portNum;
	static String ipAddress;
	
	// Identify which player is the client
	static int whichPlayer; // Identifies which player they are
	static int whoAmI; // Determines if the player is the initiator or opponent
	static String opponent = null; // Keeps track of oppponent chosen from client list view
	
	// Text display who won
	static Text winnerText;
	
	// Displays which player you are when fighting
	static Text playerDisplay; 
	
	static ListView<String> messageBoardList; // A listview of for any messages recieved from the server
	static ListView<String> clientList; // A listview of all clients connected
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	//feel free to remove the starter code from this method
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		window = primaryStage;
		window.setTitle("Initial Screen");
		
		
		window.setScene(initialSceneCreate());
		//window.setScene(thirdSceneCreate());
		//window.setScene(gameSceneCreate());
		//window.setScene(clientListSceneCreate());
		
		window.show();
	}
	
	
	public Scene initialSceneCreate() {
		Scene startScene; // Start Scene
		BorderPane startPane = new BorderPane();
		
		// BackGround ---------------------------------------------------------------------------------
		/* Load Image */
		Image imagebackground = new Image("bg.jpg", 1280, 720, false, false);
		/* Create a background from startBackground IMAGE */
	    Background background = new Background(new BackgroundImage(imagebackground, null, null, null, null));
	    
		
		// Title -------------------------------------------------------------------------------------------
		Text title = new Text();
		title.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
		title.setFill(Color.WHITE);
		//title.setStroke(Color.AQUA);
		title.setText("Rock! Paper! Scissor! Lizard! Spock!");
		
		// User Inputs in a HBOX ----------------------------------------------------------------------------
		/* IP Address */
		TextField ipAddressInput = new TextField();
		ipAddressInput.setPrefHeight(40); // Change size of textfield
		ipAddressInput.setFont(Font.font(20)); // Change font size for textfield
		ipAddressInput.setPromptText("Enter IP Address"); // Hint Text
		ipAddressInput.setFocusTraversable(false);
		/* Port */
		TextField portInput = new TextField();
		portInput.setPrefHeight(40); // Change size of textfield
		portInput.setFont(Font.font(20)); // Change font size for textfield
		portInput.setPromptText("Enter Port Number"); // Hint Text
		portInput.setFocusTraversable(false);
		/* Buttons */
		Button startButton = new Button("Start");
		startButton.setPrefSize(80, 40); // Change size of button
		startButton.setOnAction(e -> {
				//clientListScene = clientListSceneCreate();
				
				// If port input and ip address text field is not empty then change scene and start a server
				if(!portInput.getText().trim().isEmpty() && !ipAddressInput.getText().trim().isEmpty()) {
					portNum = Integer.valueOf(portInput.getText());
					ipAddress = ipAddressInput.getText();
					
					clientConnection = new Client(
						data->{
								Platform.runLater(()->{clientList.getItems().add(data.toString());
										});
						},
						data->{
								Platform.runLater(()->{messageBoardList.getItems().add(data.toString());
												});
						}
					);
						
					clientConnection.start();
					
					window.setScene(clientListSceneCreate());
					window.show();
				}	
		}); 
		
		Button quitButton = new Button("Quit");
		quitButton.setPrefSize(80, 40); // Change size of button
		quitButton.setOnAction(e ->{
			Platform.exit();
			//System.exit(0);
		});
		
		/* HBOX */
		HBox userInput = new HBox();
		userInput.getChildren().addAll(ipAddressInput, portInput, startButton, quitButton);
		userInput.setAlignment(Pos.CENTER);
		userInput.setMargin(portInput, new Insets(12));
		
		// Vbox for Center Border Pane -----------------------------------------------------------------------
		VBox centerVbox = new VBox();
		centerVbox.getChildren().addAll(title, userInput);
		centerVbox.setAlignment(Pos.CENTER);
		
		
		// Add/Modify borderPane -----------------------------------------------------------------------------
		startPane.setBackground(background); // Set the background loaded from the image
		startPane.setCenter(centerVbox);
		
		
		
		startScene = new Scene(startPane, 1280, 720); // Initial Scene
		
		return startScene; // Return Scene
		
	}
	
	static public Scene gameSceneCreate() {
		Scene gameScene; // Start Scene
		BorderPane gamePane = new BorderPane();
		
		// Menu Bar ---------------------------------------------------------------------------------------------------
		MenuBar menuBar = new MenuBar();
		Menu menuOne = new Menu("Options");
		
		MenuItem quitMenu = new MenuItem("Quit");
		quitMenu.setOnAction(e -> {
			Platform.exit();
			System.exit(0);
		});
		
		menuOne.getItems().add(quitMenu);
		menuBar.getMenus().add(menuOne);
		
		// BackGround ---------------------------------------------------------------------------------
		/* Load Image */
		Image imagebackground = new Image("bg.jpg", 1280, 720, false, false);
		/* Create a background from startBackground IMAGE */
	    Background background = new Background(new BackgroundImage(imagebackground, null, null, null, null));
	    
	    // User Input Buttons -------------------------------------------------------------------------------
	    /* Buttons to select which fighter you choose */
	    Image rockImage = new Image("rock.png", 50, 50, false, false);
	    rockButton = new ImageView(rockImage);
	    rockButton.setDisable(false);
	    rockButton.setVisible(true);
	    
	    Image paperImage = new Image("paper.png", 50, 50, false, false);
	    paperButton = new ImageView(paperImage);
	    paperButton.setDisable(false);
	    paperButton.setVisible(true);
	    
	    Image scissorImage = new Image("scissor.png", 50, 50, false, false);
	    scissorButton = new ImageView(scissorImage);
	    scissorButton.setDisable(false);
	    scissorButton.setVisible(true);
	    
	    Image lizardImage = new Image("lizard.png", 50, 50, false, false);
	    lizardButton = new ImageView(lizardImage);
	    lizardButton.setDisable(false);
	    lizardButton.setVisible(true);
	    
	    Image spockImage = new Image("spock.png", 50, 50, false, false);
	    spockButton = new ImageView(spockImage);
	    spockButton.setDisable(false);
	    spockButton.setVisible(true);
	    
	    confirmButton = new Button("Confirm");
	    confirmButton.setPrefSize(100, 10);
	    confirmButton.setDisable(false);
	    
	    
	    rockButton.setOnMouseClicked(e -> {
	    	if(whoAmI == 1) {
	    		clientConnection.gameData.initiatorPlays = "rock";
	    	}
	    	else {
	    		clientConnection.gameData.opponentPlays = "rock";
	    	}
	    	
	    	rockButton.setDisable(true);
	    	rockButton.setVisible(false);
	    	paperButton.setDisable(false);
	    	paperButton.setVisible(true);
	    	scissorButton.setDisable(false);
	    	scissorButton.setVisible(true);
	    	lizardButton.setDisable(false);
	    	lizardButton.setVisible(true);
	    	spockButton.setDisable(false);
	    	spockButton.setVisible(true);
	    });
	    

	    paperButton.setOnMouseClicked(e -> {
	    	if(whoAmI == 1) {
	    		clientConnection.gameData.initiatorPlays = "paper";
	    	}
	    	else {
	    		clientConnection.gameData.opponentPlays = "paper";
	    	}
	    	rockButton.setDisable(false);
	    	rockButton.setVisible(true);
	    	paperButton.setDisable(true);
	    	paperButton.setVisible(false);
	    	scissorButton.setDisable(false);
	    	scissorButton.setVisible(true);
	    	lizardButton.setDisable(false);
	    	lizardButton.setVisible(true);
	    	spockButton.setDisable(false);
	    	spockButton.setVisible(true);
	    });
	    
	    scissorButton.setOnMouseClicked(e -> {
	    	if(whoAmI == 1) {
	    		clientConnection.gameData.initiatorPlays = "scissor";
	    	}
	    	else {
	    		clientConnection.gameData.opponentPlays = "scissor";
	    	}
	    	rockButton.setDisable(false);
	    	rockButton.setVisible(true);
	    	paperButton.setDisable(false);
	    	paperButton.setVisible(true);
	    	scissorButton.setDisable(true);
	    	scissorButton.setVisible(false);
	    	lizardButton.setDisable(false);
	    	lizardButton.setVisible(true);
	    	spockButton.setDisable(false);
	    	spockButton.setVisible(true);
	    });
	    
	    lizardButton.setOnMouseClicked(e -> {
	    	if(whoAmI == 1) {
	    		clientConnection.gameData.initiatorPlays = "lizard";
	    	}
	    	else {
	    		clientConnection.gameData.opponentPlays = "lizard";
	    	}
	    	rockButton.setDisable(false);
	    	rockButton.setVisible(true);
	    	paperButton.setDisable(false);
	    	paperButton.setVisible(true);
	    	scissorButton.setDisable(false);
	    	scissorButton.setVisible(true);
	    	lizardButton.setDisable(true);
	    	lizardButton.setVisible(false);
	    	spockButton.setDisable(false);
	    	spockButton.setVisible(true);
	    });
	    
	    spockButton.setOnMouseClicked(e -> {
	    	if(whoAmI == 1) {
	    		clientConnection.gameData.initiatorPlays = "spock";
	    	}
	    	else {
	    		clientConnection.gameData.opponentPlays = "spock";
	    	}
	    	rockButton.setDisable(false);
	    	rockButton.setVisible(true);
	    	paperButton.setDisable(false);
	    	paperButton.setVisible(true);
	    	scissorButton.setDisable(false);
	    	scissorButton.setVisible(true);
	    	lizardButton.setDisable(false);
	    	lizardButton.setVisible(true);
	    	spockButton.setDisable(true);
	    	spockButton.setVisible(false);
	    });
	    
	    confirmButton.setOnAction(e ->{
	    	
			rockButton.setDisable(true);
			paperButton.setDisable(true);
			scissorButton.setDisable(true);
			lizardButton.setDisable(true);
			spockButton.setDisable(true);
			confirmButton.setDisable(true);
			
			try {
				clientConnection.out.writeUnshared(clientConnection.gameData);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	
					
	    });
	    
	    // Initiate playerDisplay
	    playerDisplay = new Text();
	    playerDisplay.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
	    playerDisplay.setFill(Color.WHITE);
	   
	    
	    
	    VBox playerButtons = new VBox(20);
	    playerButtons.getChildren().addAll(playerDisplay, rockButton, paperButton, scissorButton, lizardButton, spockButton, confirmButton);
	    playerButtons.setAlignment(Pos.CENTER);
	    

	    
	    // Add/Modify borderPane -----------------------------------------------------------------------------
 		gamePane.setBackground(background); // Set the background loaded from the image
 		gamePane.setCenter(playerButtons); // You info on the left
 		gamePane.setMargin(playerButtons, new Insets(10));
 		gamePane.setTop(menuBar);

 		
	    
	    gameScene = new Scene(gamePane, 350, 500);
	    return gameScene;
	}
	
	
    static public Scene thirdSceneCreate() {
		Scene thirdScene;
		BorderPane thirdBP = new BorderPane();
		
		window.setTitle("Winner Screen");
		
		// BackGround ---------------------------------------------------------------------------------
		/* Load Image */
		Image imagebackground = new Image("bg.jpg", 1280, 720, false, false);
		/* Create a background from startBackground IMAGE */
	    Background background = new Background(new BackgroundImage(imagebackground, null, null, null, null));
	    
	    
	    //  User Input Buttons -------------------------------------------------------------------------------------
	    Button playAgainButton = new Button("Play Again");
		playAgainButton.setPrefSize(100, 40); // Change size of button
		playAgainButton.setOnAction(e -> {
				// Remove player from inGame list in server
				clientConnection.gameData = new GameInfo();
				clientConnection.gameData.whichPlayer = "Player " + whichPlayer;
			
				try {
					clientConnection.out.writeUnshared((GameInfo) clientConnection.gameData);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				clientConnection.gameData = new GameInfo();
				
				window.setScene(clientListSceneCreate());
				window.show();
		}); 
		
		Button quitButton = new Button("Quit");
		quitButton.setPrefSize(100, 40); // Change size of button
		quitButton.setOnAction(e ->{
			// Remove player from inGame list in server
			clientConnection.gameData = new GameInfo();
			clientConnection.gameData.whichPlayer = "Player " + whichPlayer;
		
			try {
				clientConnection.out.writeUnshared((GameInfo) clientConnection.gameData);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			clientConnection.gameData = new GameInfo();
			
			
			
			Platform.exit();
			System.exit(0);
		});
	    
	    /* HBOX for all buttons */
		HBox playAgainHBox = new HBox(4);
		playAgainHBox.getChildren().addAll(playAgainButton, quitButton);
		playAgainHBox.setAlignment(Pos.CENTER);
		
		
		// Opponent fighter Reveal After Each Round ---------------------------------------------------
	    /* Title */
	    Text opponentImageTitle = new Text();
	    opponentImageTitle.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
	    opponentImageTitle.setFill(Color.WHITE);
		//title.setStroke(Color.AQUA);
	    opponentImageTitle.setText("Opponent Chose: ");
	    /* Images */
	    opponentRock = new ImageView(new Image("rock.png",100, 100, false, false));
	    opponentRock.setVisible(false);
	    opponentPaper = new ImageView(new Image("paper.png",100, 100, false, false));
	    opponentPaper.setVisible(false);
	    opponentScissor = new ImageView(new Image("scissor.png",100, 100, false, false));
	    opponentScissor.setVisible(false);
	    opponentLizard = new ImageView(new Image("lizard.png",100, 100, false, false));
	    opponentLizard.setVisible(false);
	    opponentSpock = new ImageView(new Image("spock.png",100, 100, false, false));
	    opponentSpock.setVisible(false);
	    
	    Group opponentImages = new Group();
	    opponentImages.getChildren().addAll(opponentRock, opponentPaper, opponentScissor, opponentLizard, opponentSpock);
	    
	    /* VBox containg title and group of images */
	    VBox opponentFighterVBox = new VBox(4);
	    opponentFighterVBox.getChildren().addAll(opponentImageTitle, opponentImages);
	    opponentFighterVBox.setAlignment(Pos.CENTER);
	    
	    
	    // VBOX containing all nodes-----------------------------------------------------------------
	    // Title -------------------------------------------------------------------------------------------
 		winnerText = new Text();
 		winnerText.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
 		winnerText.setFill(Color.WHITE);
 		//title.setStroke(Color.AQUA);
 		winnerText.setText("Winner is ..");
	    
	    
	    VBox centerVBox = new VBox(4);
	    centerVBox.getChildren().addAll(opponentFighterVBox, winnerText, playAgainHBox);
	    centerVBox.setAlignment(Pos.CENTER);
		
		
		// Modify / Add into BorderPane --------------------------------------------------------------------------
		thirdBP.setBackground(background);
		thirdBP.setCenter(centerVBox);
		
		
		thirdScene = new Scene(thirdBP, 600, 720);
		return thirdScene;
	}

    
    static public Scene clientListSceneCreate() {
    	Scene clientListScene; // Create Scene
    	BorderPane clientListBP = new BorderPane(); // Create BorderPane
    	
    	opponent = new String(); // Reset opponent string everytime clientListScene is created
    	
    	window.setTitle("Client List");
    	
    	// Menu Bar ---------------------------------------------------------------------------------------------------
		MenuBar menuBar = new MenuBar();
		Menu menuOne = new Menu("Options");
		
		MenuItem quitMenu = new MenuItem("Quit");
		quitMenu.setOnAction(e -> {
			Platform.exit();
			System.exit(0);
		});
		
		menuOne.getItems().add(quitMenu);
		menuBar.getMenus().add(menuOne);
    	
    	// BackGround ---------------------------------------------------------------------------------
		/* Load Image */
		Image imagebackground = new Image("bg.jpg", 1280, 720, false, false);
		/* Create a background from startBackground IMAGE */
	    Background background = new Background(new BackgroundImage(imagebackground, null, null, null, null));
	    
 		
 		// VBox for Challengers -------------------------------------------------------------------
	    /* Title */
  		Text challengerstitle = new Text();
  		challengerstitle.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
  		challengerstitle.setFill(Color.WHITE);
  		//title.setStroke(Color.AQUA);
  		challengerstitle.setText("  Challengers  ");
  		
  		clientList = new ListView<String>(); // Initiate ListView of clients connected
  		clientList.setOnMouseClicked(e -> {
  			opponent = clientList.getSelectionModel().getSelectedItem(); // Gets string of selected item
  			
  		});
  		
  		/* VBox */
 		VBox clientListVBox = new VBox(2);
 		clientListVBox.getChildren().addAll(challengerstitle, clientList);
 		clientListVBox.setAlignment(Pos.CENTER);
 		
 		// Message Board VBox --------------------------------------------------------------------
 		 /* Title */
  		Text messageBoardtitle = new Text();
  		messageBoardtitle.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
  		messageBoardtitle.setFill(Color.WHITE);
  		//title.setStroke(Color.AQUA);
  		messageBoardtitle.setText("Message Board");
  		
  		/* ListView for message board */
 		messageBoardList = new ListView<String>();
 
 		
 		/* VBox */
 		VBox messageBoardVBox = new VBox(2);
 		messageBoardVBox.getChildren().addAll(messageBoardtitle, messageBoardList);
 		messageBoardVBox.setAlignment(Pos.CENTER);
 		
 		
 		// HBox containing ClientList Vbox and Message Board Vbox ---------------------------------
 		HBox listViewInfoHBox = new HBox(10);
 		listViewInfoHBox.getChildren().addAll(clientListVBox, messageBoardVBox);
 		listViewInfoHBox.setAlignment(Pos.CENTER);
 		
 		// HBox containing buttons confirm, accept, and decline ---------------------------------------------
 		/* Confirm Button */
 		challengeButton = new Button("Challenge");
 		challengeButton.setPrefSize(80, 40);
 		challengeButton.setDisable(false); // By Default its disabled
 		challengeButton.setVisible(true); // By Default its disabled
 		challengeButton.setOnAction(e -> {
 			String whoAmIString = "Player " + String.valueOf(whichPlayer); // Convert int to string
 			
 			// If player chose himself, warn the player
  			if(opponent.equals(whoAmIString)) {
  				messageBoardList.getItems().add("Can't Challenge Yourself, Choose Another Player");
  			}
  			// Else send information to the server
  			else {
  				try {
  					clientConnection.out.writeUnshared((String) "Play Against"); // Send who you are first
  				} catch (IOException e1) {
  					// TODO Auto-generated catch block
  					e1.printStackTrace();
  				}
  	  			
  	  			try {
  					clientConnection.out.writeUnshared((String) whoAmIString); // Send String of who you are to the server
  				} catch (IOException e1) {
  					// TODO Auto-generated catch block
  					e1.printStackTrace();
  				}
  	  			
  	  			try {
  					clientConnection.out.writeUnshared((String) opponent); // Then opponent you want to compete
  				} catch (IOException e1) {
  					// TODO Auto-generated catch block
  					e1.printStackTrace();
  				}
  	  			
  	  			challengeButton.setDisable(true); // Disable Confirm button after choosing opponent
  			}
  			
 		});
 		/* Accept Button */
 		acceptButton = new Button("Accept");
 		acceptButton.setPrefSize(80, 40);
 		acceptButton.setDisable(true); // By Default its disabled
 		acceptButton.setVisible(false); // By Default its disabled
 		acceptButton.setOnAction(e -> {
 			try {
				clientConnection.out.writeUnshared((String) "Challenge Accepted"); // If opponent accepts, send a message to the server
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
 			
 			try {
				clientConnection.out.writeUnshared((String) clientConnection.initiator); // Send the server who the initiator was
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
 			
 			try {
 				String whoAmIString = "Player " + String.valueOf(whichPlayer);
				clientConnection.out.writeUnshared(whoAmIString); // Send the server who the you are
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
 			
 			// Disable accept and decline button after responding
 			acceptButton.setDisable(true);
 			acceptButton.setVisible(false); 
 			declineButton.setDisable(true); 
 			declineButton.setVisible(false); 
 			challengeButton.setVisible(true);
 			challengeButton.setDisable(false);
 		});
 		
 		/* Decline Button */
 		declineButton = new Button("Decline");
 		declineButton.setPrefSize(80, 40);
 		declineButton.setDisable(true); // By Default its disabled
 		declineButton.setVisible(false); // By Default its disabled
 		declineButton.setOnAction(e -> {
 			try {
				clientConnection.out.writeUnshared((String) "Challenge Declined"); // If opponent declines, send a message to the server
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
 			
 			try {
				clientConnection.out.writeUnshared((String) clientConnection.initiator); // Send the server who the initiator was
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
 			
 			// Disable accept and decline button after responding
 			acceptButton.setDisable(true);
 			acceptButton.setVisible(false); 
 			declineButton.setDisable(true); 
 			declineButton.setVisible(false); 
 			challengeButton.setVisible(true);
 			challengeButton.setDisable(false);
 			
 			// Reset initiator
 			clientConnection.initiator = new String();
 		});
 		
 		/* HBox containing both buttons */
 		HBox acceptDeclineHBox = new HBox(4);
 		acceptDeclineHBox.getChildren().addAll(challengeButton, acceptButton, declineButton);
 		acceptDeclineHBox.setAlignment(Pos.CENTER);
 		
 		// ClientInfoVBox containing the two listview and buttons
 		VBox clientInfoVBox = new VBox(8);
 		clientInfoVBox.getChildren().addAll(listViewInfoHBox, acceptDeclineHBox);
 		clientInfoVBox.setAlignment(Pos.CENTER);
 		
 		
    	// Modify / Add to BorderPane ---------------------------------------------------------------
 		clientListBP.setBackground(background);
 		clientListBP.setCenter(clientInfoVBox);
 		clientListBP.setTop(menuBar);
 		
 		// Send a message to the server to get the players connected list
 		try {
			clientConnection.out.writeUnshared((String) "Get Players Connected List");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
 		
 		// Let client know which player they are
 		messageBoardList.getItems().add("You are player " + String.valueOf(whichPlayer));
 		
 		clientListScene = new Scene(clientListBP, 800, 720);
    	return clientListScene; // Return Scene
    }

}
