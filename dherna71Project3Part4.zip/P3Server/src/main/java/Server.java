import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.function.Consumer;


import javafx.application.Platform;
import javafx.scene.control.ListView;


public class Server extends ServerRPSLS{
	int clientcount = 1;
	int numConnected = 0;
	int portNumber = ServerRPSLS.portNum;
	ArrayList<ClientThread> clients = new ArrayList<ClientThread>();
	TheServer server;
	private Consumer<Serializable> callback;
	
	GameInfo gameData = new GameInfo();
	
	
	Server(Consumer<Serializable> call){
		callback = call;
		server = new TheServer();
		server.start();
	}
	
	// Default
	Server(){
		
	}
	
	
		public class TheServer extends Thread{
			public void run() {
				
				try(ServerSocket mysocket = new ServerSocket(portNumber);){
					System.out.println("Server is waiting for a client!");
					
					while(true) {
						// Create only two threads and stop there
						if(numConnected < 2) {
							ClientThread c = new ClientThread(mysocket.accept(), clientcount);
							callback.accept("Player has connected to server: " + "Player #" + clientcount);
							clients.add(c);
							c.start();
							
							
							clientcount++;
							numConnected++; // Updates Number of connections connected
							numConnectionsTextField.setText(String.valueOf(numConnected));
							
						}

							
					}//end of while
				}//end of try
				catch(Exception e) {
					callback.accept("Server socket did not launch");
				}
			} // end of run
		} // end of TheServer
		
		
		class ClientThread extends Thread{
			Socket connection;
			int count;
			ObjectInputStream in;
			ObjectOutputStream out;
			String winner;
			
			ClientThread(Socket s, int count){
				this.connection = s;
				this.count = count;	
			}
			
			public void updateClients(GameInfo data) {
				for(int i = 0; i < clients.size(); i++) {
					ClientThread t = clients.get(i);
					try {
					 t.out.writeUnshared(data);
					}
					catch(Exception e) {}
				}
			}
			
			public void run(){
				try {
					in = new ObjectInputStream(connection.getInputStream());
					out = new ObjectOutputStream(connection.getOutputStream());
					connection.setTcpNoDelay(true);	
					gameData.whoAmI = count;
					out.writeUnshared(gameData);
					gameData.whoAmI = 0;
					
					if(count == 2){
						gameData.message = "Choose Your Fighter!";
						updateClients(gameData);
						gameData.message = "NULL";
					}
					
				}
				catch(Exception e) {
					System.out.println("Streams not open");
				}
				
					
				 while(true) {
					    try {
			    	
				    		GameInfo data = (GameInfo) in.readUnshared();
	
					    	// Read player 1 data
					    	if (count == 1) {
					    		gameData.p1Plays = data.p1Plays;
					    		callback.accept("Player  " + count + " chose " + data.p1Plays); // Update server listview what each player chose
					    	}
					    	// Read player 2 data
					    	else if (count == 2) {
					    		gameData.p2Plays = data.p2Plays;
					    		callback.accept("Player  " + count + " chose " + data.p2Plays); // Update server listview what each player chose
					    	} 
					    	
					    	
							if(numConnected == 2 && gameData.p1Plays != "NULL" && gameData.p2Plays != "NULL") {
					    		winner = whoWon(gameData.p1Plays,gameData.p2Plays);
					    		
					    		if(winner.equals("P1")) {
					    			gameData.p1Points++;
					    			playerOnePointsDisplay.setText(Integer.toString(gameData.p1Points));
					    			callback.accept("Player 1 Won The Round");
					    			gameData.roundWon = "Player 1 Won The Round!";
					    			
					    			
					    			updateClients((GameInfo) gameData);
					    			
					    			gameData.p1Plays = "NULL";
									gameData.p2Plays = "NULL";
									gameData.roundWon = "NULL";
									
					    		}
					    		else if (winner.equals("P2")) {
					    			gameData.p2Points++;
					    			playerTwoPointsDisplay.setText(Integer.toString(gameData.p2Points));
					    			callback.accept("Player 2 Won The Round");
					    			gameData.roundWon = "Player 2 Won The Round!";
					    			
					    			updateClients((GameInfo) gameData);
					    			
					    			gameData.p1Plays = "NULL";
									gameData.p2Plays = "NULL";
									gameData.roundWon = "NULL";
									
					    		}
					    		else {
					    			gameData.roundWon = "Round Is A Tie!";
					    			callback.accept("Round Is A Tie");
					    			
					    			updateClients((GameInfo) gameData);
					    			
					    			gameData.p1Plays = "NULL";
									gameData.p2Plays = "NULL";
									gameData.roundWon = "NULL";
					    		}
					    	
					    	} 
							if (!determineWinner(gameData.p1Points, gameData.p2Points).equals("NULL")) {
								winner = determineWinner(gameData.p1Points, gameData.p2Points);
								if(winner.equals("1")) {
									gameData.gameWon = "Player 1 Won The Game!";
									
									updateClients((GameInfo) gameData);
									
									callback.accept("Player 1 Won The Game!");
								}
								else {
									gameData.gameWon = "Player 2 Won The Game!";
									
									updateClients((GameInfo) gameData);
									
									callback.accept("Player 2 Won The Game!");
								}
								
								gameData.p1Points = 0;
								gameData.p2Points = 0;
								gameData.gameWon = "NULL";
								
								playerOnePointsDisplay.setText(Integer.toString(gameData.p1Points));
								playerTwoPointsDisplay.setText(Integer.toString(gameData.p2Points));
								
								updateClients((GameInfo) gameData);
								
							} 
						
					    	
					    }
					    catch(Exception e) {
					    	gameData = new GameInfo(); // Reset Game Info
					    	gameData.message = "Player "+count+" has left the server!";
					    	callback.accept("OOOOPPs...Something wrong with the socket from player: " + count + "....closing down!");
					    	updateClients(gameData);
					    	clientcount--;
					    	clientcount--;
					    	gameData.message = "Waiting For An Opponent";
					    	gameData.whoAmI = clientcount;
					    	updateClients(gameData);
					    	gameData = new GameInfo();
					    	updateClients(gameData);
					    	clients.remove(this);
					    	numConnected--; 
					    	
					    	numConnectionsTextField.setText(String.valueOf(numConnected));
					    	
					    	break;
					    }
					} // end of while
				}//end of run
			
		}//end of client thread
		
		
	  //determines which player won each round
	  static public String whoWon(String playsP1, String playsP2 ) {
		  switch (playsP1) {
	      case "scissor":
	        if ((playsP2.equals("paper")) || (playsP2.equals("lizard"))) {
	          return "P1";
	        }
	        else if ((playsP2.equals("spock")) || (playsP2.equals("rock"))) {
	          return "P2";
	        }
	        else {
	          return "tie";
	        }
	      case "paper":
	        if ((playsP2.equals("rock")) || (playsP2.equals("spock"))) {
	          return "P1";
	        }
	        else if ((playsP2.equals("scissor")) || (playsP2.equals("lizard"))) {
	          return "P2";
	        }
	        else {
	          return "tie";
	        }
	      case "lizard":
	        if ((playsP2.equals("paper")) || (playsP2.equals("spock"))) {
	          return "P1";
	        }
	        else if ((playsP2.equals("scissor")) || (playsP2.equals("rock"))) {
	          return "P2";
	        }
	        else {
	          return "tie";
	        }
	      case "spock":
	        if ((playsP2.equals("rock")) || (playsP2.equals("scissor"))) {
	          return "P1";
	        }
	        else if ((playsP2.equals("lizard")) || (playsP2.equals("paper"))) {
	          return "P2";
	        }
	        else {
	          return "tie";
	        }
	      case "rock":
	        if ((playsP2.equals("lizard")) || (playsP2.equals("scissor"))) {
	          return "P1";
	        }
	        else if ((playsP2.equals("spock")) || (playsP2.equals("paper"))) {
	          return "P2";
	        }
	        else {
	          return "tie";
	        }
	      default:
	        return "NULL";
	    }
	    
	  }
	  
	  // Determines which player won each game
	  static public String determineWinner (int pointsP1, int pointsP2 ) {
		    if ( pointsP1 == 3) {
		      return "1";
		    }
		    else if (pointsP2 == 3) {
		      return "2";
		    }
		    return "NULL";
		   }
		
}
