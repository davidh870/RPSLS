import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class GameLogicTest {
    Server Logic = new Server();

    @Test
    void check () {
        assertEquals("Server", Logic.getClass().getName(), "not correct class name");
    }
    
    @Test
    void whoWonTest0 () {
        assertEquals("P1", Logic.whoWon("scissor","paper"), "not winner");
        assertEquals("P1", Logic.whoWon("scissor","lizard"), "not winner");
        assertEquals("P2", Logic.whoWon("scissor","spock"), "not winner");
        assertEquals("P2", Logic.whoWon("scissor","rock"), "not winner");
        assertEquals("tie", Logic.whoWon("scissor","scissor"), "not winner");
    }

    @Test
    void whoWonTest1 () {
        assertEquals("P1", Logic.whoWon("paper","rock"), "not winner");
        assertEquals("P1", Logic.whoWon("paper","spock"), "not winner");
        assertEquals("P2", Logic.whoWon("paper","scissor"), "not winner");
        assertEquals("P2", Logic.whoWon("paper","lizard"), "not winner");
        assertEquals("tie", Logic.whoWon("paper","paper"), "not winner");
    }

    @Test
    void whoWonTest2 () {
        assertEquals("P1", Logic.whoWon("lizard","paper"), "not winner");
        assertEquals("P1", Logic.whoWon("lizard","spock"), "not winner");
        assertEquals("P2", Logic.whoWon("lizard","scissor"), "not winner");
        assertEquals("P2", Logic.whoWon("lizard","rock"), "not winner");
        assertEquals("tie", Logic.whoWon("lizard","lizard"), "not winner");
    }

    @Test
    void whoWonTest3 () {
        assertEquals("P1", Logic.whoWon("spock","rock"), "not winner");
        assertEquals("P1", Logic.whoWon("spock","scissor"), "not winner");
        assertEquals("P2", Logic.whoWon("spock","lizard"), "not winner");
        assertEquals("P2", Logic.whoWon("spock","paper"), "not winner");
        assertEquals("tie", Logic.whoWon("spock","spock"), "not winner");
    }

    @Test
    void whoWonTest4 () {
        assertEquals("P1", Logic.whoWon("rock","lizard"), "not winner");
        assertEquals("P1", Logic.whoWon("rock","scissor"), "not winner");
        assertEquals("P2", Logic.whoWon("rock","spock"), "not winner");
        assertEquals("P2", Logic.whoWon("rock","paper"), "not winner");
        assertEquals("tie", Logic.whoWon("rock","rock"), "not winner");
    }

    @Test
    void gameWinner0 () {
        assertEquals("NULL", Logic.determineWinner(0,0), "not winner");

    }

    @Test
    void gameWinner1 () {
        assertEquals("1", Logic.determineWinner(3,0), "not winner");

    }
    @Test
    void gameWinner2 () {
        assertEquals("2", Logic.determineWinner(0,3), "not winner");

    }
    @Test
    void gameWinner3 () {
        assertEquals("NULL", Logic.determineWinner(4,0), "not winner");

    }
}
