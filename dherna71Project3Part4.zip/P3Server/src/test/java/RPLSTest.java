import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class RPLSTest{

	GameInfo gamedata;

	@BeforeEach
	void init() {
		gamedata = new GameInfo();
	}

	@AfterEach
	void check(){
		assertEquals("GameInfo", gamedata.getClass().getName(), "not correct class name");
	}

	@Test
	void gameInfodefaultcase0Test(){
		assertEquals(0, gamedata.p1Points, "not corect");
	}

	@Test
	void gameInfodefaultcase1Test(){
		assertEquals(0, gamedata.p2Points, "not corect");
	}
	@Test
	void gameInfodefaultcase2Test(){
		assertEquals("NULL", gamedata.p1Plays, "not corect");
	}
	@Test
	void gameInfodefaultcase3Test(){
		assertEquals("NULL", gamedata.p2Plays, "not corect");
	}
	@Test
	void gameInfodefaultcase4Test(){
		assertEquals("NULL", gamedata.roundWon, "not corect");
	}

	@Test
	void gameInfodefaultcase5Test(){
		assertEquals("NULL", gamedata.gameWon, "not corect");
	}

	@Test
	void gameInfoChange0Test(){
		gamedata.p1Points++;
		assertEquals(1, gamedata.p1Points, "not corect");
	}
	@Test
	void gameInfoChange1Test(){
		gamedata.p2Points++;
		assertEquals(1, gamedata.p2Points, "not corect");
	}
	@Test
	void gameInfoChange2Test (){
		gamedata.p1Plays = "rock";
		assertEquals("rock", gamedata.p1Plays, "not corect");
	}
	@Test
	void gameInfoChange3Test (){
		gamedata.p2Plays = "lizard";
		assertEquals("lizard", gamedata.p2Plays, "not corect");
	}
	@Test
	void gameInfoChange4Test(){
		gamedata.roundWon = "winner";
		assertEquals("winner", gamedata.roundWon, "not corect");
	}
	@Test
	void gameInfoChange45Test(){
		gamedata.gameWon = "winner1";
		assertEquals("winner1", gamedata.gameWon, "not corect");
	}



}
