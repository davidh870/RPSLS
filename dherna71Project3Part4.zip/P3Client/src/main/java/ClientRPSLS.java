import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ClientRPSLS extends Application {
	// Variables 
	static Stage window;
	Scene initialScene;
	static Scene gameScene;
	
	
	// Game Points Text Field
	static TextField playerOnePointsDisplay;
	static TextField playerTwoPointsDisplay;
	// Buttons For Game
	static ImageView rockButton;
	static ImageView paperButton;
	static ImageView scissorButton;
	static ImageView lizardButton;
	static ImageView spockButton;
	static Button confirmButton;
	static Button changeSceneButton;
	
	// Opponent fighter Image
	static ImageView opponentRock;
	static ImageView opponentPaper;
	static ImageView opponentScissor;
	static ImageView opponentLizard;
	static ImageView opponentSpock;
	
	// Connection Data
	static public Client clientConnection;
	static int portNum;
	static String ipAddress;
	
	static int whichPlayer;
	
	static ListView<String> listItems;
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	//feel free to remove the starter code from this method
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		window = primaryStage;
		window.setTitle("Initial Screen");
		
		initialScene = initialSceneCreate();
		window.setScene(initialScene);
		//window.setScene(thirdSceneCreate());
		//window.setScene(gameSceneCreate());
		
		window.show();
	}
	
	
	public Scene initialSceneCreate() {
		Scene startScene; // Start Scene
		BorderPane startPane = new BorderPane();
		
		// BackGround ---------------------------------------------------------------------------------
		/* Load Image */
		Image imagebackground = new Image("bg.jpg", 1280, 720, false, false);
		/* Create a background from startBackground IMAGE */
	    Background background = new Background(new BackgroundImage(imagebackground, null, null, null, null));
	    
		
		// Title -------------------------------------------------------------------------------------------
		Text title = new Text();
		title.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
		title.setFill(Color.WHITE);
		//title.setStroke(Color.AQUA);
		title.setText("Rock! Paper! Scissor! Lizard! Spock!");
		
		// User Inputs in a HBOX ----------------------------------------------------------------------------
		/* IP Address */
		TextField ipAddressInput = new TextField();
		ipAddressInput.setPrefHeight(40); // Change size of textfield
		ipAddressInput.setFont(Font.font(20)); // Change font size for textfield
		ipAddressInput.setPromptText("Enter IP Address"); // Hint Text
		ipAddressInput.setFocusTraversable(false);
		/* Port */
		TextField portInput = new TextField();
		portInput.setPrefHeight(40); // Change size of textfield
		portInput.setFont(Font.font(20)); // Change font size for textfield
		portInput.setPromptText("Enter Port Number"); // Hint Text
		portInput.setFocusTraversable(false);
		/* Buttons */
		Button startButton = new Button("Start");
		startButton.setPrefSize(80, 40); // Change size of button
		startButton.setOnAction(e -> {
				gameScene = gameSceneCreate();
				
				// If port input and ip address text field is not empty then change scene and start a server
				if(!portInput.getText().trim().isEmpty() && !ipAddressInput.getText().trim().isEmpty()) {
					portNum = Integer.valueOf(portInput.getText());
					ipAddress = ipAddressInput.getText();
					
					clientConnection = new Client(data->{
						Platform.runLater(()->{listItems.getItems().add(data.toString());
										});
					});
						
					clientConnection.start();
					
					window.setTitle("Lets Play");
					window.setScene(gameScene);
					window.show();
				}	
		}); 
		
		Button quitButton = new Button("Quit");
		quitButton.setPrefSize(80, 40); // Change size of button
		quitButton.setOnAction(e ->{
			Platform.exit();
			//System.exit(0);
		});
		
		/* HBOX */
		HBox userInput = new HBox();
		userInput.getChildren().addAll(ipAddressInput, portInput, startButton, quitButton);
		userInput.setAlignment(Pos.CENTER);
		userInput.setMargin(portInput, new Insets(12));
		
		// Vbox for Center Border Pane -----------------------------------------------------------------------
		VBox centerVbox = new VBox();
		centerVbox.getChildren().addAll(title, userInput);
		centerVbox.setAlignment(Pos.CENTER);
		
		
		// Add/Modify borderPane -----------------------------------------------------------------------------
		startPane.setBackground(background); // Set the background loaded from the image
		startPane.setCenter(centerVbox);
		
		
		
		startScene = new Scene(startPane, 1280, 720); // Initial Scene
		
		return startScene; // Return Scene
		
	}
	
	static public Scene gameSceneCreate() {
		Scene gameScene; // Start Scene
		BorderPane gamePane = new BorderPane();
		
		// Menu Bar ---------------------------------------------------------------------------------------------------
		MenuBar menuBar = new MenuBar();
		Menu menuOne = new Menu("Options");
		
		MenuItem quitMenu = new MenuItem("Quit");
		quitMenu.setOnAction(e -> {
			Platform.exit();
			System.exit(0);
		});
		
		menuOne.getItems().add(quitMenu);
		menuBar.getMenus().add(menuOne);
		
		// BackGround ---------------------------------------------------------------------------------
		/* Load Image */
		Image imagebackground = new Image("bg.jpg", 1280, 720, false, false);
		/* Create a background from startBackground IMAGE */
	    Background background = new Background(new BackgroundImage(imagebackground, null, null, null, null));
	    
	    // User Input Buttons -------------------------------------------------------------------------------
	    /* Buttons to select which fighter you choose */
	    Image rockImage = new Image("rock.png", 50, 50, false, false);
	    rockButton = new ImageView(rockImage);
	    rockButton.setDisable(true);
	    rockButton.setVisible(false);
	    
	    Image paperImage = new Image("paper.png", 50, 50, false, false);
	    paperButton = new ImageView(paperImage);
	    paperButton.setDisable(true);
	    paperButton.setVisible(false);
	    
	    Image scissorImage = new Image("scissor.png", 50, 50, false, false);
	    scissorButton = new ImageView(scissorImage);
	    scissorButton.setDisable(true);
	    scissorButton.setVisible(false);
	    
	    Image lizardImage = new Image("lizard.png", 50, 50, false, false);
	    lizardButton = new ImageView(lizardImage);
	    lizardButton.setDisable(true);
	    lizardButton.setVisible(false);
	    
	    Image spockImage = new Image("spock.png", 50, 50, false, false);
	    spockButton = new ImageView(spockImage);
	    spockButton.setDisable(true);
	    spockButton.setVisible(false);
	    
	    confirmButton = new Button("Confirm");
	    confirmButton.setPrefSize(100, 10);
	    confirmButton.setDisable(true);
	    
	    changeSceneButton = new Button("Complete");
	    confirmButton.setPrefSize(100, 10);
	    changeSceneButton.setVisible(false);
	    changeSceneButton.setOnAction(e->{
	    	window.setScene(thirdSceneCreate());
	    	window.show();
	    });
	    
	    rockButton.setOnMouseClicked(e -> {
	    	if(whichPlayer == 1) {
	    		clientConnection.gameData.p1Plays = "rock";
	    	}
	    	else {
	    		clientConnection.gameData.p2Plays = "rock";
	    	}
	    	
	    	rockButton.setDisable(true);
	    	rockButton.setVisible(false);
	    	paperButton.setDisable(false);
	    	paperButton.setVisible(true);
	    	scissorButton.setDisable(false);
	    	scissorButton.setVisible(true);
	    	lizardButton.setDisable(false);
	    	lizardButton.setVisible(true);
	    	spockButton.setDisable(false);
	    	spockButton.setVisible(true);
	    });
	    

	    paperButton.setOnMouseClicked(e -> {
	    	if(whichPlayer == 1) {
	    		clientConnection.gameData.p1Plays = "paper";
	    	}
	    	else {
	    		clientConnection.gameData.p2Plays = "paper";
	    	}
	    	rockButton.setDisable(false);
	    	rockButton.setVisible(true);
	    	paperButton.setDisable(true);
	    	paperButton.setVisible(false);
	    	scissorButton.setDisable(false);
	    	scissorButton.setVisible(true);
	    	lizardButton.setDisable(false);
	    	lizardButton.setVisible(true);
	    	spockButton.setDisable(false);
	    	spockButton.setVisible(true);
	    });
	    
	    scissorButton.setOnMouseClicked(e -> {
	    	if(whichPlayer == 1) {
	    		clientConnection.gameData.p1Plays = "scissor";
	    	}
	    	else {
	    		clientConnection.gameData.p2Plays = "scissor";
	    	}
	    	rockButton.setDisable(false);
	    	rockButton.setVisible(true);
	    	paperButton.setDisable(false);
	    	paperButton.setVisible(true);
	    	scissorButton.setDisable(true);
	    	scissorButton.setVisible(false);
	    	lizardButton.setDisable(false);
	    	lizardButton.setVisible(true);
	    	spockButton.setDisable(false);
	    	spockButton.setVisible(true);
	    });
	    
	    lizardButton.setOnMouseClicked(e -> {
	    	if(whichPlayer == 1) {
	    		clientConnection.gameData.p1Plays = "lizard";
	    	}
	    	else {
	    		clientConnection.gameData.p2Plays = "lizard";
	    	}
	    	rockButton.setDisable(false);
	    	rockButton.setVisible(true);
	    	paperButton.setDisable(false);
	    	paperButton.setVisible(true);
	    	scissorButton.setDisable(false);
	    	scissorButton.setVisible(true);
	    	lizardButton.setDisable(true);
	    	lizardButton.setVisible(false);
	    	spockButton.setDisable(false);
	    	spockButton.setVisible(true);
	    });
	    
	    spockButton.setOnMouseClicked(e -> {
	    	if(whichPlayer == 1) {
	    		clientConnection.gameData.p1Plays = "spock";
	    	}
	    	else {
	    		clientConnection.gameData.p2Plays = "spock";
	    	}
	    	rockButton.setDisable(false);
	    	rockButton.setVisible(true);
	    	paperButton.setDisable(false);
	    	paperButton.setVisible(true);
	    	scissorButton.setDisable(false);
	    	scissorButton.setVisible(true);
	    	lizardButton.setDisable(false);
	    	lizardButton.setVisible(true);
	    	spockButton.setDisable(true);
	    	spockButton.setVisible(false);
	    });
	    
	    confirmButton.setOnAction(e ->{
	    	if(whichPlayer == 1) {
	    		if(!clientConnection.gameData.p1Plays.equals("NULL")) {
					clientConnection.send((GameInfo)clientConnection.gameData);
					
					rockButton.setDisable(true);
					paperButton.setDisable(true);
					scissorButton.setDisable(true);
					lizardButton.setDisable(true);
					spockButton.setDisable(true);
					confirmButton.setDisable(true);
					clientConnection.gameData.p1Plays = "NULL";
	    	
	    		}
	    		else {
		    		listItems.getItems().add("Please Choose A Fighter");
		    	}
	    	}
	    	else{
	    		if(!clientConnection.gameData.p2Plays.equals("NULL")) {
					clientConnection.send((GameInfo)clientConnection.gameData);
					
					rockButton.setDisable(true);
					paperButton.setDisable(true);
					scissorButton.setDisable(true);
					lizardButton.setDisable(true);
					spockButton.setDisable(true);
					confirmButton.setDisable(true);
					clientConnection.gameData.p2Plays = "NULL";
	    	
	    		}
	    		else {
		    		listItems.getItems().add("Please Choose A Fighter");
		    	}
	    	}
					
	    });
	    
	    
	    VBox playerButtons = new VBox(20);
	    playerButtons.getChildren().addAll(rockButton, paperButton, scissorButton, lizardButton, spockButton, confirmButton, changeSceneButton);
	    
	    // Player One Information ----------------------------------------------------------------
	    /* Title */
	    Text playerOneTitle = new Text();
	    playerOneTitle.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
	    playerOneTitle.setFill(Color.WHITE);
		//title.setStroke(Color.AQUA);
	    playerOneTitle.setText("Player One");
	    
	    /* HBOX for player one Points */
	    Label playerOnePointsLabel = new Label("Points: ");
	    playerOnePointsLabel.setTextFill(Color.WHITE);
	    playerOnePointsLabel.setFont(Font.font("verdana", 20));
	    playerOnePointsDisplay = new TextField();
	    playerOnePointsDisplay.setEditable(false); // Read Only Text Field
	    playerOnePointsDisplay.setText("0");
	    HBox playerOnePointsHBOX = new HBox(1);
	    playerOnePointsHBOX.getChildren().addAll(playerOnePointsLabel, playerOnePointsDisplay);
	    
	    
	    
	    /* VBOX containing all information of player one */
	    VBox playerOneInfo = new VBox(10);
	    playerOneInfo.getChildren().addAll(playerOneTitle, playerOnePointsHBOX);
	    playerOneInfo.setAlignment(Pos.TOP_CENTER);
	   
	    
	    //  Player Two Information ----------------------------------------------------------------
	    /* Title */
	    Text playerTwoTitle = new Text();
	    playerTwoTitle.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
	    playerTwoTitle.setFill(Color.WHITE);
		//title.setStroke(Color.AQUA);
	    playerTwoTitle.setText("Player Two");
	    
	    /* HBOX for player two Points */
	    Label playerTwoPointsLabel = new Label("Points: ");
	    playerTwoPointsLabel.setTextFill(Color.WHITE);
	    playerTwoPointsLabel.setFont(Font.font("verdana", 20));
	    playerTwoPointsDisplay = new TextField();
	    playerTwoPointsDisplay.setEditable(false); // Read Only Text Field
	    playerTwoPointsDisplay.setText("0");
	    HBox playerTwoPointsHBOX = new HBox(1);
	    listItems = new ListView();
	    playerTwoPointsHBOX.getChildren().addAll(playerTwoPointsLabel, playerTwoPointsDisplay);
	    
	    /* VBOX containing all information of player two */
	    VBox playerTwoInfo = new VBox(10);
	    playerTwoInfo.getChildren().addAll(playerTwoTitle, playerTwoPointsHBOX);
	    playerTwoInfo.setAlignment(Pos.TOP_CENTER);
	    
	    
	    // Right Side Information ---------------------------------------------------------------------------
	    /* VBOX containing all information of YOU */
	    VBox rightInfo = new VBox(40);
	    rightInfo.getChildren().addAll(playerOneInfo, playerTwoInfo, listItems);
	    
	    
	    // Opponent fighter Reveal After Each Round ---------------------------------------------------
	    /* Title */
	    Text opponentImageTitle = new Text();
	    opponentImageTitle.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
	    opponentImageTitle.setFill(Color.WHITE);
		//title.setStroke(Color.AQUA);
	    opponentImageTitle.setText("Opponent Chose: ");
	    /* Images */
	    opponentRock = new ImageView(new Image("rock.png",100, 100, false, false));
	    opponentRock.setVisible(false);
	    opponentPaper = new ImageView(new Image("paper.png",100, 100, false, false));
	    opponentPaper.setVisible(false);
	    opponentScissor = new ImageView(new Image("scissor.png",100, 100, false, false));
	    opponentScissor.setVisible(false);
	    opponentLizard = new ImageView(new Image("lizard.png",100, 100, false, false));
	    opponentLizard.setVisible(false);
	    opponentSpock = new ImageView(new Image("spock.png",100, 100, false, false));
	    opponentSpock.setVisible(false);
	    
	    Group opponentImages = new Group();
	    opponentImages.getChildren().addAll(opponentRock, opponentPaper, opponentScissor, opponentLizard, opponentSpock);
	    
	    /* VBox containg title and group of images */
	    VBox opponentFighterVBox = new VBox(4);
	    opponentFighterVBox.getChildren().addAll(opponentImageTitle, opponentImages);
	    opponentFighterVBox.setAlignment(Pos.CENTER);

	    
	    // Add/Modify borderPane -----------------------------------------------------------------------------
 		gamePane.setBackground(background); // Set the background loaded from the image
 		gamePane.setLeft(playerButtons); // You info on the left
 		gamePane.setMargin(playerButtons, new Insets(10));
 		gamePane.setRight(rightInfo); // Opponent info on the right
 		gamePane.setMargin(rightInfo, new Insets(10));
 		gamePane.setTop(menuBar);
 		gamePane.setCenter(opponentFighterVBox);
 		
	    
	    gameScene = new Scene(gamePane, 1280, 720);
	    return gameScene;
	}
	
	
    static public Scene thirdSceneCreate() {
		Scene thirdScene;
		BorderPane thirdBP = new BorderPane();
		
		// BackGround ---------------------------------------------------------------------------------
		/* Load Image */
		Image imagebackground = new Image("bg.jpg", 1280, 720, false, false);
		/* Create a background from startBackground IMAGE */
	    Background background = new Background(new BackgroundImage(imagebackground, null, null, null, null));
	    
	    
	    //  User Input Buttons -------------------------------------------------------------------------------------
	    Button playAgainButton = new Button("Play Again");
		playAgainButton.setPrefSize(80, 40); // Change size of button
		playAgainButton.setOnAction(e -> {
				gameScene = gameSceneCreate();
				
				window.setTitle("Lets Play");
				window.setScene(gameScene);
				window.show();
				
				// Buttons For Game
				rockButton.setDisable(false);
				rockButton.setVisible(true);
				paperButton.setDisable(false);
				paperButton.setVisible(true);
				scissorButton.setDisable(false);
				scissorButton.setVisible(true);
				lizardButton.setDisable(false);
				lizardButton.setVisible(true);
				spockButton.setDisable(false);
				spockButton.setVisible(true);
				confirmButton.setDisable(false);
				changeSceneButton.setVisible(false);
				
		}); 
		
		Button quitButton = new Button("Quit");
		quitButton.setPrefSize(80, 40); // Change size of button
		quitButton.setOnAction(e ->{
			Platform.exit();
			System.exit(0);
		});
	    
	    /* HBOX for all buttons */
		HBox playAgainHBox = new HBox(4);
		playAgainHBox.getChildren().addAll(playAgainButton, quitButton);
		playAgainHBox.setAlignment(Pos.CENTER);
		
		
		// Modify / Add into BorderPane --------------------------------------------------------------------------
		thirdBP.setBackground(background);
		thirdBP.setCenter(playAgainHBox);
		
		
		thirdScene = new Scene(thirdBP, 600, 720);
		return thirdScene;
	}



}
