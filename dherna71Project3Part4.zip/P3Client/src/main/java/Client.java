import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.function.Consumer;




public class Client extends Thread{
	public GameInfo gameData = new GameInfo();
	
	Socket socketClient;
	
	ObjectOutputStream out;
	ObjectInputStream in;
	
	int portnum;
	String ipaddress;
	
	private Consumer<Serializable> callback;
	
	Client(Consumer<Serializable> call){
	
		callback = call;
		portnum = ClientRPSLS.portNum;
		ipaddress = ClientRPSLS.ipAddress;
	}
	
	public void run() {	
		
		try {
		socketClient= new Socket(ipaddress,portnum);
	    out = new ObjectOutputStream(socketClient.getOutputStream());
	    in = new ObjectInputStream(socketClient.getInputStream());
	    socketClient.setTcpNoDelay(true);
		}
		catch(Exception e) {}
		
		while(true) {
			 
			try {
				GameInfo data = (GameInfo)in.readUnshared();
				
				// Update Player points in GUI
				ClientRPSLS.playerOnePointsDisplay.setText(Integer.toString(data.p1Points));
				ClientRPSLS.playerTwoPointsDisplay.setText(Integer.toString(data.p2Points));
				
				
				// Disable all opponent Images
				ClientRPSLS.opponentRock.setVisible(false);
				ClientRPSLS.opponentPaper.setVisible(false);
				ClientRPSLS.opponentScissor.setVisible(false);
				ClientRPSLS.opponentLizard.setVisible(false);
				ClientRPSLS.opponentSpock.setVisible(false);
				
				
				
				if(data.whoAmI != 0) {
					callback.accept("You Are Player " + data.whoAmI);
					ClientRPSLS.whichPlayer = data.whoAmI;
					
				}
				
				if(!data.message.equals("NULL")) {
					callback.accept(data.message);
					
					if(data.message.equals("Choose Your Fighter!")) {
						ClientRPSLS.rockButton.setDisable(false);
						ClientRPSLS.rockButton.setVisible(true);
						ClientRPSLS.paperButton.setDisable(false);
						ClientRPSLS.paperButton.setVisible(true);
						ClientRPSLS.scissorButton.setDisable(false);
						ClientRPSLS.scissorButton.setVisible(true);
						ClientRPSLS.lizardButton.setDisable(false);
						ClientRPSLS.lizardButton.setVisible(true);
						ClientRPSLS.spockButton.setDisable(false);
						ClientRPSLS.spockButton.setVisible(true);
						ClientRPSLS.confirmButton.setDisable(false);
					}
					
					if(data.message.equals("Waiting For An Opponent")) {
						ClientRPSLS.rockButton.setDisable(true);
						ClientRPSLS.rockButton.setVisible(false);
						ClientRPSLS.paperButton.setDisable(true);
						ClientRPSLS.paperButton.setVisible(false);
						ClientRPSLS.scissorButton.setDisable(true);
						ClientRPSLS.scissorButton.setVisible(false);
						ClientRPSLS.lizardButton.setDisable(true);
						ClientRPSLS.lizardButton.setVisible(false);
						ClientRPSLS.spockButton.setDisable(true);
						ClientRPSLS.spockButton.setVisible(false);
						ClientRPSLS.confirmButton.setDisable(true);
					}
				} 
				
				if(!data.roundWon.equals("NULL")) {
					callback.accept(data.roundWon);
					
					ClientRPSLS.rockButton.setDisable(false);
					ClientRPSLS.rockButton.setVisible(true);
					ClientRPSLS.paperButton.setDisable(false);
					ClientRPSLS.paperButton.setVisible(true);
					ClientRPSLS.scissorButton.setDisable(false);
					ClientRPSLS.scissorButton.setVisible(true);
					ClientRPSLS.lizardButton.setDisable(false);
					ClientRPSLS.lizardButton.setVisible(true);
					ClientRPSLS.spockButton.setDisable(false);
					ClientRPSLS.spockButton.setVisible(true);
					ClientRPSLS.confirmButton.setDisable(false);
					
					
					if(ClientRPSLS.whichPlayer == 1) {
						if(data.p2Plays.equals("rock")) {
							ClientRPSLS.opponentRock.setVisible(true);
						}
						else if(data.p2Plays.equals("paper")) {
							ClientRPSLS.opponentPaper.setVisible(true);
						}
						else if(data.p2Plays.equals("scissor")) {
							ClientRPSLS.opponentScissor.setVisible(true);
						}
						else if(data.p2Plays.equals("lizard")) {
							ClientRPSLS.opponentLizard.setVisible(true);
						}
						else if(data.p2Plays.equals("spock")) {
							ClientRPSLS.opponentSpock.setVisible(true);
						}
						
					}
					else if(ClientRPSLS.whichPlayer == 2) {
						if(data.p1Plays.equals("rock")) {
							ClientRPSLS.opponentRock.setVisible(true);
						}
						else if(data.p1Plays.equals("paper")) {
							ClientRPSLS.opponentPaper.setVisible(true);
						}
						else if(data.p1Plays.equals("scissor")) {
							ClientRPSLS.opponentScissor.setVisible(true);
						}
						else if(data.p1Plays.equals("lizard")) {
							ClientRPSLS.opponentLizard.setVisible(true);
						}
						else if(data.p1Plays.equals("spock")) {
							ClientRPSLS.opponentSpock.setVisible(true);
						}
						
					}
					
				}
				if(!data.gameWon.equals("NULL")) {
					callback.accept(data.gameWon);
					ClientRPSLS.rockButton.setDisable(true);
					ClientRPSLS.rockButton.setVisible(false);
					ClientRPSLS.paperButton.setDisable(true);
					ClientRPSLS.paperButton.setVisible(false);
					ClientRPSLS.scissorButton.setDisable(true);
					ClientRPSLS.scissorButton.setVisible(false);
					ClientRPSLS.lizardButton.setDisable(true);
					ClientRPSLS.lizardButton.setVisible(false);
					ClientRPSLS.spockButton.setDisable(true);
					ClientRPSLS.spockButton.setVisible(false);
					ClientRPSLS.confirmButton.setDisable(true);
					ClientRPSLS.changeSceneButton.setVisible(true);
					
				}
				
				
				
				
				
			}
			catch(Exception e) {}
		}
	
    }
	
	public void send(GameInfo data) {
		
		try {
			out.writeUnshared(data);
			//out.reset();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
