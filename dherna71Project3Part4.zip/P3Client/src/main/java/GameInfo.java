import java.io.Serializable;

import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class GameInfo implements  Serializable{
  int p1Points;
  int p2Points; 
  String p1Plays;
  String p2Plays;
  String roundWon; 
  String gameWon;
  String message;
  int whoAmI;
  


  // Default constructor
  GameInfo() {
    this.p1Points = 0;
    this.p2Points = 0;
    this.p1Plays = "NULL";
    this.p2Plays = "NULL";
    this.roundWon = "NULL";
    this.gameWon = "NULL";
    this.message = "NULL";
    this.whoAmI = 0;
  }

 
}