import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.function.Consumer;


import javafx.application.Platform;
import javafx.scene.control.ListView;


public class Server extends ServerRPSLS{
	int count = 1;
	int numConnected = 0;
	int portNumber = ServerRPSLS.portNum;
	ArrayList<ClientThread> clients = new ArrayList<ClientThread>();
	TheServer server;
	private Consumer<Serializable> callback;
	
	GameInfo gameData = new GameInfo(0,0,"NULL","NULL", "NULL","NULL");
	
	
	Server(Consumer<Serializable> call){
		callback = call;
		server = new TheServer();
		server.start();
	}
	
	
		public class TheServer extends Thread{
			public void run() {
				
				try(ServerSocket mysocket = new ServerSocket(portNumber);){
					System.out.println("Server is waiting for a client!");
					
					while(true) {
						// Create only two threads and stop there
						if(numConnected < 2) {
							ClientThread c = new ClientThread(mysocket.accept(), count);
							callback.accept("client has connected to server: " + "client #" + count);
							clients.add(c);
							c.start();
							
							count++;
							numConnected++; // Updates Number of connections connected
							numConnectionsTextField.setText(String.valueOf(numConnected));
						}
						
							
					}//end of while
				}//end of try
				catch(Exception e) {
					callback.accept("Server socket did not launch");
				}
			} // end of run
		} // end of TheServer
		
		
		class ClientThread extends Thread{
			Socket connection;
			int count;
			ObjectInputStream in;
			ObjectOutputStream out;
			String winner;
			
			ClientThread(Socket s, int count){
				this.connection = s;
				this.count = count;	
			}
			
			public void updateClients(String message) {
				for(int i = 0; i < clients.size(); i++) {
					ClientThread t = clients.get(i);
					try {
					 t.out.writeObject(message);
					}
					catch(Exception e) {}
				}
			}
			
			public void run(){
				try {
					in = new ObjectInputStream(connection.getInputStream());
					out = new ObjectOutputStream(connection.getOutputStream());
					connection.setTcpNoDelay(true);	
				}
				catch(Exception e) {
					System.out.println("Streams not open");
				}
				
				updateClients("new player on server: player #"+count);
					
				 while(true) {
					    try {
					    	
						    	try {
						    		GameInfo data = (GameInfo) in.readObject();
						    		gameData.p1Plays = data.p1Plays;
								} catch (IOException e) {
									// TODO Auto-generated catch block
									System.out.println("TESTST");
									e.printStackTrace();
								}
					 
					    		
					    		
					
					    	
					    	
					    	// Read player 1 data
					    	/*if (count == 1) {
					    		gameData.p1Plays = data.p1Plays;
					    		System.out.println(data.p1Plays);
					    	}
					    	// Read player 2 data
					    	else if (count == 2) {
					    		gameData.p2Plays = data.p1Plays;
					    	} 
					    	callback.accept("player  " + count + " chose " + data); // Update server listview what each player chose
					    	//updateClients("client #"+count+" said: "+data);
					    	
					    	
							if(numConnected == 2 && gameData.p1Plays != "NULL" && gameData.p2Plays != "NULL") {
					    		winner = whoWon(gameData.p1Plays,gameData.p2Plays);
					    		
					    		if(winner == "P1") {
					    			gameData.p1Points++;
					    			playerOnePointsDisplay.setText(Integer.toString(gameData.p1Points));
					    			gameData.roundWon = "You've Won The Round!";
					    			
					    			clients.get(0).out.writeObject((GameInfo) gameData);
					    			
					    			gameData.p1Points--;
					    			gameData.p2Points++;
					    			gameData.roundWon = "You've Lost The Round!";
					    			clients.get(1).out.writeObject((GameInfo) gameData);
					    			
					    			gameData.p1Points++;
					    			gameData.p2Points--;
					    			gameData.p1Plays = "NULL";
									gameData.p2Plays = "NULL";
									
					    		}
					    		else if (winner == "P2") {
					    			gameData.p2Points++;
					    			playerTwoPointsDisplay.setText(Integer.toString(gameData.p2Points));
					    			gameData.roundWon = "You've Won The Round!";
					    			
					    			gameData.p1Points++;
					    			gameData.p2Points--;
					    			clients.get(1).out.writeObject((GameInfo) gameData);
					    			
					    			gameData.p1Points--;
					    			gameData.p2Points++;
					    			gameData.roundWon = "You've Lost The Round!";
					    			clients.get(0).out.writeObject((GameInfo) gameData);
					    			
					    			gameData.p1Plays = "NULL";
									gameData.p2Plays = "NULL";
									gameData.roundWon = "NULL";
					    		}
					    		else {
					    			gameData.roundWon = "Round Is A Tie!";
					    			clients.get(0).out.writeObject((GameInfo) gameData);
					    			clients.get(1).out.writeObject((GameInfo) gameData);
					    			
					    			
					    			gameData.p1Plays = "NULL";
									gameData.p2Plays = "NULL";
									gameData.roundWon = "NULL";
					    		}
					    	
					    	} 
							if (!determineWinner(gameData.p1Points, gameData.p2Points).equals("NULL")) {
								winner = determineWinner(gameData.p1Points, gameData.p2Points);
								if(winner.equals("1")) {
									gameData.gameWon = "You've Won The Game!";
									clients.get(0).out.writeObject((GameInfo) gameData);
									
									gameData.gameWon = "You've Lost The Game!";
									clients.get(1).out.writeObject((GameInfo) gameData);
									
									callback.accept("Player One Won The Game!");
								}
								else {
									gameData.gameWon = "You've Won The Game!";
									clients.get(1).out.writeObject((GameInfo) gameData);
									
									gameData.gameWon = "You've Lost The Game!";
									clients.get(0).out.writeObject((GameInfo) gameData);
									
									callback.accept("Player Two Won The Game!");
								}
								
								gameData.p1Points = 0;
								gameData.p2Points = 0;
								gameData.gameWon = "NULL";
								
								playerOnePointsDisplay.setText(Integer.toString(gameData.p1Points));
								playerTwoPointsDisplay.setText(Integer.toString(gameData.p2Points));
								
								clients.get(0).out.writeObject((GameInfo) gameData);
				    			clients.get(1).out.writeObject((GameInfo) gameData);
								
							} */
						
					    	
					    }
					    catch(Exception e) {
					    	callback.accept("OOOOPPs...Something wrong with the socket from player: " + count + "....closing down!");
					    	updateClients("player #"+count+" has left the server!");
					    	clients.remove(this);
					    	numConnected--; 
					    	count--;
					    	numConnectionsTextField.setText(String.valueOf(numConnected));
					    	gameData = new GameInfo(0,0,"NULL", "NULL", "NULL", "NULL"); // Reset Game Info
					    	
					    	break;
					    }
					} // end of while
				}//end of run
			
		}//end of client thread
		
		
	  //determines which player won each round
	  static public String whoWon(String playsP1, String playsP2 ) {
		  switch (playsP1) {
	      case "scissor":
	        if ((playsP2.equals("paper")) || (playsP2.equals("lizard"))) {
	          return "P1";
	        }
	        else if ((playsP2.equals("spock")) || (playsP2.equals("rock"))) {
	          return "P2";
	        }
	        else {
	          return "tie";
	        }
	      case "paper":
	        if ((playsP2.equals("rock")) || (playsP2.equals("spock"))) {
	          return "P1";
	        }
	        else if ((playsP2.equals("scissor")) || (playsP2.equals("lizard"))) {
	          return "P2";
	        }
	        else {
	          return "tie";
	        }
	      case "lizard":
	        if ((playsP2.equals("paper")) || (playsP2.equals("spock"))) {
	          return "P1";
	        }
	        else if ((playsP2.equals("scissor")) || (playsP2.equals("rock"))) {
	          return "P2";
	        }
	        else {
	          return "tie";
	        }
	      case "spock":
	        if ((playsP2.equals("rock")) || (playsP2.equals("scissor"))) {
	          return "P1";
	        }
	        else if ((playsP2.equals("lizard")) || (playsP2.equals("paper"))) {
	          return "P2";
	        }
	        else {
	          return "tie";
	        }
	      case "rock":
	        if ((playsP2.equals("lizard")) || (playsP2.equals("scissor"))) {
	          return "P1";
	        }
	        else if ((playsP2.equals("spock")) || (playsP2.equals("paper"))) {
	          return "P2";
	        }
	        else {
	          return "tie";
	        }
	      default:
	        return "NULL";
	    }
	    
	  }
	  
	  // Determines which player won each game
	  static public String determineWinner (int pointsP1, int pointsP2 ) {
		    if ( pointsP1 == 3) {
		      return "1";
		    }
		    else if (pointsP2 == 3) {
		      return "2";
		    }
		    return "NULL";
		   }
		
}
