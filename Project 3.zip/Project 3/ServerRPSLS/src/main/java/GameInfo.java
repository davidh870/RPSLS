import java.io.Serializable;

public class GameInfo implements  Serializable{
  int p1Points;
  int p2Points; 
  String p1Plays;
  String p2Plays;
  String roundWon; 
  String gameWon;
  


  // Parametized constructor
  GameInfo(int pointsP1, int pointsP2, String playsP1, String playsP2, String roundwon, String gamewon) {
    this.p1Points = pointsP1;
    this.p2Points = pointsP2;
    this.p1Plays = playsP1;
    this.p2Plays = playsP2;
    this.roundWon = roundwon;
    this.gameWon = gamewon;
  }

 
}