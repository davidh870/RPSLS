import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.HashMap;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class ServerRPSLS extends Application {
	// Variables to create Initial Scene
	Stage window; 
	
	Scene initialScene;
	Scene serverInfoScene;
	
	Server serverConnection;
	
	ListView<String> gameInfoListView; // Displays any game info / client data
	
	static TextField numConnectionsTextField; // Keeps track number of connections
	static TextField playerOnePointsDisplay; // Keeps track of points for player one
	static TextField playerTwoPointsDisplay; // Keeps track of points for player two
	static int portNum = 0; // Port number by default is 5555

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	//feel free to remove the starter code from this method
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		window = primaryStage;
		
		window.setOnCloseRequest(new EventHandler<WindowEvent>() {
	        @Override
	        public void handle(WindowEvent t) {
	            Platform.exit();
	            System.exit(0);
	        }
	    });
		
		window.setTitle("Server RPSLS");
		
		initialScene = initialSceneCreate(); // Return a new initial Scene
		window.setScene(initialScene); // Change to initial Scene
		window.show();
	}
	
	
	public Scene initialSceneCreate() {
		Scene startScene; // Start Scene
		BorderPane startPane = new BorderPane();
		
		// BackGround ---------------------------------------------------------------------------------
		/* Load Image */
		Image imagebackground = new Image("bg.jpg", 1280, 720, false, false);
		/* Create a background from startBackground IMAGE */
	    Background background = new Background(new BackgroundImage(imagebackground, null, null, null, null));
	    
		
		// Title -------------------------------------------------------------------------------------------
		Text title = new Text();
		title.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
		title.setFill(Color.WHITE);
		//title.setStroke(Color.AQUA);
		title.setText("Rock! Paper! Scissor! Lizard! Spock!");
		
		// User Inputs in a HBOX ----------------------------------------------------------------------------
		/* Port */
		TextField portInput = new TextField();
		portInput.setPrefHeight(40); // Change size of textfield
		portInput.setFont(Font.font(20)); // Change font size for textfield
		portInput.setPromptText("Enter Port Number"); // Hint Text
		portInput.setFocusTraversable(false);
		/* Buttons */
		Button startButton = new Button("Start");
		startButton.setPrefSize(80, 40); // Change size of button
		startButton.setOnAction(e -> {
			serverInfoScene = gameServer();
			
			// If port input text field is not empty then change scene and start a server
			if(!portInput.getText().trim().isEmpty()) {
				portNum = Integer.valueOf(portInput.getText());
				
				serverConnection = new Server(data -> {
					Platform.runLater(()->{
						gameInfoListView.getItems().add(data.toString());
					});
				}); 
				
				window.setTitle("Game Server Information");
				window.setScene(serverInfoScene);
				window.show();
			}
		}); 
		
		Button quitButton = new Button("Quit");
		quitButton.setPrefSize(80, 40); // Change size of button
		quitButton.setOnAction(e ->{
			Platform.exit();
			System.exit(0);
		});
		
		/* HBOX */
		HBox userInput = new HBox();
		userInput.getChildren().addAll(portInput, startButton, quitButton);
		userInput.setAlignment(Pos.CENTER);
		userInput.setMargin(portInput, new Insets(12));
		
		// Vbox for Center Border Pane -----------------------------------------------------------------------
		VBox centerVbox = new VBox();
		centerVbox.getChildren().addAll(title, userInput);
		centerVbox.setAlignment(Pos.CENTER);
		
		
		// Add/Modify borderPane -----------------------------------------------------------------------------
		startPane.setBackground(background); // Set the background loaded from the image
		startPane.setCenter(centerVbox);
		
		
		
		startScene = new Scene(startPane, 1280, 720); // Initial Scene
		
		return startScene; // Return Scene
		
	}
	
	
	
	public Scene gameServer() {
		Scene gameServerScene; // Game scene
		BorderPane gamePane = new BorderPane();
		
		// BackGround ---------------------------------------------------------------------------------------------
		/* Load Image */
		Image imagebackground = new Image("bg.jpg", 1280, 720, false, false);
		/* Create a background from startBackground IMAGE */
	    Background background = new Background(new BackgroundImage(imagebackground, null, null, null, null));

		// Vbox for Player 1 Info ----------------------------------------------------------------------------------
	    /* Player One Title */
	    Text playerOneTitle = new Text();
	    playerOneTitle.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
	    playerOneTitle.setFill(Color.WHITE);
		//title.setStroke(Color.AQUA);
	    playerOneTitle.setText("Player One");
	    
	    /* HBOX for player one Points */
	    Label playerOnePointsLabel = new Label("Points: ");
	    playerOnePointsLabel.setTextFill(Color.WHITE);
	    playerOnePointsLabel.setFont(Font.font("verdana", 20));
	    playerOnePointsDisplay = new TextField();
	    playerOnePointsDisplay.setEditable(false); // Read Only Text Field
	    playerOnePointsDisplay.setText("0");
	    HBox playerOnePointsHBOX = new HBox(1);
	    playerOnePointsHBOX.getChildren().addAll(playerOnePointsLabel, playerOnePointsDisplay);
	    
	    /* Add Player One info into VBOX */
	    VBox playerOneInfoVBOX = new VBox(5);
	    playerOneInfoVBOX.getChildren().addAll(playerOneTitle, playerOnePointsHBOX);
	    
	    
	    // Vbox for Player 2 Info ----------------------------------------------------------------------------------------
	    /* Player Two Title */
	    Text playerTwoTitle = new Text();
	    playerTwoTitle.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
	    playerTwoTitle.setFill(Color.WHITE);
		//title.setStroke(Color.AQUA);
	    playerTwoTitle.setText("Player Two");
	    
	    /* HBOX for player two Points */
	    Label playerTwoPointsLabel = new Label("Points: ");
	    playerTwoPointsLabel.setTextFill(Color.WHITE);
	    playerTwoPointsLabel.setFont(Font.font("verdana", 20));
	    playerTwoPointsDisplay = new TextField();
	    playerTwoPointsDisplay.setEditable(false); // Read Only Text Field
	    playerTwoPointsDisplay.setText("0");
	    HBox playerTwoPointsHBOX = new HBox(1);
	    playerTwoPointsHBOX.getChildren().addAll(playerTwoPointsLabel, playerTwoPointsDisplay);
	    
	    /* Add Player Two info into VBOX */
	    VBox playerTwoInfoVBOX = new VBox(5);
	    playerTwoInfoVBOX.getChildren().addAll(playerTwoTitle, playerTwoPointsHBOX);
		
	    
	    // Vbox containing both player info ------------------------------------------------------------------------------
	    VBox playerInfoVBOX = new VBox(150);
	    playerInfoVBOX.getChildren().addAll(playerOneInfoVBOX, playerTwoInfoVBOX);
	    playerInfoVBOX.setAlignment(Pos.CENTER_LEFT);
	    
	    
	    // Number Of Connections Info ------------------------------------------------------------------------------------
	    /* Label */
	    Label numConnectionsLabel = new Label();
	    numConnectionsLabel.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
	    numConnectionsLabel.setTextFill(Color.WHITE);
	    numConnectionsLabel.setText("Number Of Connections: ");
	    
	    /* TextField */
	    numConnectionsTextField = new TextField();
	    numConnectionsTextField.setEditable(false); // Read Only Text Field
	    numConnectionsTextField.setText("0");
	    
	    /* HBox */
	    HBox numConnectionsHBox = new HBox(1);
	    numConnectionsHBox.getChildren().addAll(numConnectionsLabel, numConnectionsTextField);
	    
	    // VBox containing num of connections and game info history ---------------------------------------------------
	    /* List View */
	    gameInfoListView = new ListView();
	    
	    /* VBox */
	    VBox gameInfoVBox = new VBox(80);
	    gameInfoVBox.getChildren().addAll(numConnectionsHBox, gameInfoListView);
	    
	    
	    // Menu Bar ---------------------------------------------------------------------------------------------------
		MenuBar menuBar = new MenuBar();
		Menu menuOne = new Menu("Options");
		
		MenuItem quitMenu = new MenuItem("Quit");
		quitMenu.setOnAction(e -> {
			Platform.exit();
			System.exit(0);
		});
		
		menuOne.getItems().add(quitMenu);
		menuBar.getMenus().add(menuOne);
	   
	    
		// Add/Modify gamePane --------------------------------------------------------------------------------------------
	    gamePane.setBackground(background); // Set the background for borderpane
	    gamePane.setLeft(playerInfoVBOX);
	    gamePane.setMargin(playerInfoVBOX, new Insets(10));
	    gamePane.setRight(gameInfoVBox);
	    gamePane.setMargin(gameInfoVBox, new Insets(10));
	    gamePane.setTop(menuBar);
	    
		
	    gameServerScene = new Scene(gamePane, 800, 720);
	    
		return gameServerScene;
	}
	
}
