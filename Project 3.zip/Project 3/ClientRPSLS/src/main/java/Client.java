import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.function.Consumer;

import javafx.scene.Scene;
import javafx.scene.control.Button;



public class Client extends Thread{
	public GameInfo gameData = new GameInfo();
	
	Socket socketClient;
	
	ObjectOutputStream out;
	ObjectInputStream in;
	
	int portnum;
	String ipaddress;
	
	private Consumer<Serializable> callback;
	
	Client(Consumer<Serializable> call){
	
		callback = call;
		portnum = ClientRPSLS.portNum;
		ipaddress = ClientRPSLS.ipAddress;
	}
	
	public void run() {	
		
		try {
		socketClient= new Socket(ipaddress,portnum);
	    out = new ObjectOutputStream(socketClient.getOutputStream());
	    in = new ObjectInputStream(socketClient.getInputStream());
	    socketClient.setTcpNoDelay(true);
		}
		catch(Exception e) {}
		
		while(true) {
			 
			try {
				GameInfo data = (GameInfo)in.readUnshared();
				gameData = data;
				
				
				ClientRPSLS.playerOnePointsDisplay.setText(Integer.toString(gameData.p1Points));
				ClientRPSLS.playerTwoPointsDisplay.setText(Integer.toString(gameData.p2Points));
				
				
				if(gameData.whoAmI != 0) {
					callback.accept("You Are Player " + gameData.whoAmI);
					ClientRPSLS.whichPlayer = gameData.whoAmI;
					
				}
				
				if(!gameData.message.equals("NULL")) {
					callback.accept(gameData.message);
					
					if(gameData.message.equals("Choose Your Fighter!")) {
						ClientRPSLS.rockButton.setDisable(false);
						ClientRPSLS.paperButton.setDisable(false);
						ClientRPSLS.scissorButton.setDisable(false);
						ClientRPSLS.lizardButton.setDisable(false);
						ClientRPSLS.spockButton.setDisable(false);
						ClientRPSLS.confirmButton.setDisable(false);
					}
					
					if(gameData.message.equals("Waiting For An Opponent")) {
						ClientRPSLS.rockButton.setDisable(true);
						ClientRPSLS.paperButton.setDisable(true);
						ClientRPSLS.scissorButton.setDisable(true);
						ClientRPSLS.lizardButton.setDisable(true);
						ClientRPSLS.spockButton.setDisable(true);
						ClientRPSLS.confirmButton.setDisable(true);
					}
				} 
				
				if(!gameData.roundWon.equals("NULL")) {
					callback.accept(gameData.roundWon);
					
					ClientRPSLS.rockButton.setDisable(false);
					ClientRPSLS.paperButton.setDisable(false);
					ClientRPSLS.scissorButton.setDisable(false);
					ClientRPSLS.lizardButton.setDisable(false);
					ClientRPSLS.spockButton.setDisable(false);
					ClientRPSLS.confirmButton.setDisable(false);
				}
				if(!gameData.gameWon.equals("NULL")) {
					callback.accept(gameData.gameWon);
					System.out.println("TEST");
					ClientRPSLS.rockButton.setDisable(false);
					ClientRPSLS.paperButton.setDisable(false);
					ClientRPSLS.scissorButton.setDisable(false);
					ClientRPSLS.lizardButton.setDisable(false);
					ClientRPSLS.spockButton.setDisable(false);
					ClientRPSLS.confirmButton.setDisable(false);
					
					//Activate Third Scene
					Scene thirdScene = ClientRPSLS.thirdSceneCreate();
					ClientRPSLS.window.setScene(thirdScene);
					
					
				}
				
				
				
				
				
			}
			catch(Exception e) {}
		}
	
    }
	
	public void send(GameInfo data) {
		
		try {
			out.writeUnshared(data);
			//out.reset();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
