import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.function.Consumer;



public class Client extends Thread{
	public GameInfo gameData = new GameInfo(0,0,"NULL","NULL", "NULL", "NULL");
	
	Socket socketClient;
	
	ObjectOutputStream out;
	ObjectInputStream in;
	
	int portnum;
	String ipaddress;
	
	private Consumer<Serializable> callback;
	
	Client(Consumer<Serializable> call){
	
		callback = call;
		portnum = ClientRPSLS.portNum;
		ipaddress = ClientRPSLS.ipAddress;
	}
	
	public void run() {	
		
		try {
		socketClient= new Socket(ipaddress,portnum);
	    out = new ObjectOutputStream(socketClient.getOutputStream());
	    in = new ObjectInputStream(socketClient.getInputStream());
	    socketClient.setTcpNoDelay(true);
		}
		catch(Exception e) {}
		
		while(true) {
			 
			try {
				GameInfo data = (GameInfo)in.readObject();
				gameData = data;
				
				
				ClientRPSLS.youPointsDisplay.setText(Integer.toString(gameData.p1Points));
				ClientRPSLS.opponentPointsDisplay.setText(Integer.toString(gameData.p2Points));
				
				if(!gameData.roundWon.equals("NULL")) {
					callback.accept(gameData.roundWon);
				}
				if(!gameData.gameWon.equals("NULL")) {
					callback.accept(gameData.gameWon);
				}
				
				
				
			}
			catch(Exception e) {}
		}
	
    }
	
	public void send(GameInfo data) {
		
		try {
			out.writeObject(data);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
