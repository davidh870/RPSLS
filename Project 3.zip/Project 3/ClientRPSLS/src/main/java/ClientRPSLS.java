import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.HashMap;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class ClientRPSLS extends Application {
	// Variables 
	Stage window;
	Scene initialScene;
	Scene gameScene;
	
	static TextField youPointsDisplay;
	static TextField opponentPointsDisplay;
	
	
	public Client clientConnection;
	static int portNum;
	static String ipAddress;
	
	ListView<String> listItems;
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	//feel free to remove the starter code from this method
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		window = primaryStage;
		window.setTitle("Initial Screen");
		
		initialScene = initialSceneCreate();
		window.setScene(initialScene);
		window.show();
	}
	
	
	public Scene initialSceneCreate() {
		Scene startScene; // Start Scene
		BorderPane startPane = new BorderPane();
		
		// BackGround ---------------------------------------------------------------------------------
		/* Load Image */
		Image imagebackground = new Image("bg.jpg", 1280, 720, false, false);
		/* Create a background from startBackground IMAGE */
	    Background background = new Background(new BackgroundImage(imagebackground, null, null, null, null));
	    
		
		// Title -------------------------------------------------------------------------------------------
		Text title = new Text();
		title.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
		title.setFill(Color.WHITE);
		//title.setStroke(Color.AQUA);
		title.setText("Rock! Paper! Scissor! Lizard! Spock!");
		
		// User Inputs in a HBOX ----------------------------------------------------------------------------
		/* IP Address */
		TextField ipAddressInput = new TextField();
		ipAddressInput.setPrefHeight(40); // Change size of textfield
		ipAddressInput.setFont(Font.font(20)); // Change font size for textfield
		ipAddressInput.setPromptText("Enter IP Address"); // Hint Text
		ipAddressInput.setFocusTraversable(false);
		/* Port */
		TextField portInput = new TextField();
		portInput.setPrefHeight(40); // Change size of textfield
		portInput.setFont(Font.font(20)); // Change font size for textfield
		portInput.setPromptText("Enter Port Number"); // Hint Text
		portInput.setFocusTraversable(false);
		/* Buttons */
		Button startButton = new Button("Start");
		startButton.setPrefSize(80, 40); // Change size of button
		startButton.setOnAction(e -> {
				gameScene = gameSceneCreate();
				
				// If port input and ip address text field is not empty then change scene and start a server
				if(!portInput.getText().trim().isEmpty() && !ipAddressInput.getText().trim().isEmpty()) {
					portNum = Integer.valueOf(portInput.getText());
					ipAddress = ipAddressInput.getText();
					
					clientConnection = new Client(data->{
						Platform.runLater(()->{listItems.getItems().add(data.toString());
										});
					});
						
					clientConnection.start();
					
					window.setTitle("Game Information");
					window.setScene(gameScene);
					window.show();
				}	
		}); 
		
		Button quitButton = new Button("Quit");
		quitButton.setPrefSize(80, 40); // Change size of button
		quitButton.setOnAction(e ->{
			Platform.exit();
			System.exit(0);
		});
		
		/* HBOX */
		HBox userInput = new HBox();
		userInput.getChildren().addAll(ipAddressInput, portInput, startButton, quitButton);
		userInput.setAlignment(Pos.CENTER);
		userInput.setMargin(portInput, new Insets(12));
		
		// Vbox for Center Border Pane -----------------------------------------------------------------------
		VBox centerVbox = new VBox();
		centerVbox.getChildren().addAll(title, userInput);
		centerVbox.setAlignment(Pos.CENTER);
		
		
		// Add/Modify borderPane -----------------------------------------------------------------------------
		startPane.setBackground(background); // Set the background loaded from the image
		startPane.setCenter(centerVbox);
		
		
		
		startScene = new Scene(startPane, 1280, 720); // Initial Scene
		
		return startScene; // Return Scene
		
	}
	
	public Scene gameSceneCreate() {
		Scene gameScene; // Start Scene
		BorderPane gamePane = new BorderPane();
		
		// Menu Bar ---------------------------------------------------------------------------------------------------
		MenuBar menuBar = new MenuBar();
		Menu menuOne = new Menu("Options");
		
		MenuItem quitMenu = new MenuItem("Quit");
		quitMenu.setOnAction(e -> {
			Platform.exit();
			System.exit(0);
		});
		
		menuOne.getItems().add(quitMenu);
		menuBar.getMenus().add(menuOne);
		
		// BackGround ---------------------------------------------------------------------------------
		/* Load Image */
		Image imagebackground = new Image("bg.jpg", 1280, 720, false, false);
		/* Create a background from startBackground IMAGE */
	    Background background = new Background(new BackgroundImage(imagebackground, null, null, null, null));
	    
	    // You (PlayerOne) Information ----------------------------------------------------------------
	    /* Title */
	    Text youTitle = new Text();
	    youTitle.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
	    youTitle.setFill(Color.WHITE);
		//title.setStroke(Color.AQUA);
	    youTitle.setText("You");
	    
	    /* HBOX for player one Points */
	    Label youPointsLabel = new Label("Points: ");
	    youPointsLabel.setTextFill(Color.WHITE);
	    youPointsLabel.setFont(Font.font("verdana", 20));
	    youPointsDisplay = new TextField();
	    youPointsDisplay.setEditable(false); // Read Only Text Field
	    youPointsDisplay.setText("0");
	    HBox youPointsHBOX = new HBox(1);
	    youPointsHBOX.getChildren().addAll(youPointsLabel, youPointsDisplay);
	    
	    /* Buttons to select which fighter you choose */
	    Button rockButton = new Button("Rock");
	    rockButton.setPrefSize(100, 10);
	    Button paperButton = new Button("Paper");
	    paperButton.setPrefSize(100, 10);
	    Button scissorButton = new Button("Scissor");
	    scissorButton.setPrefSize(100, 10);
	    Button lizardButton = new Button("Lizard");
	    lizardButton.setPrefSize(100, 10);
	    Button spockButton = new Button("Spock");
	    spockButton.setPrefSize(100, 10);
	    Button confirmButton = new Button("Confirm");
	    confirmButton.setPrefSize(100, 10);
	    
	    rockButton.setOnAction(e -> {
	    	clientConnection.gameData.p1Plays = "rock";
	    	rockButton.setDisable(true);
	    	paperButton.setDisable(false);
	    	scissorButton.setDisable(false);
	    	lizardButton.setDisable(false);
	    	spockButton.setDisable(false);
	    });
	    
	    paperButton.setOnAction(e -> {
	    	clientConnection.gameData.p1Plays = "paper";
	    	rockButton.setDisable(false);
	    	paperButton.setDisable(true);
	    	scissorButton.setDisable(false);
	    	lizardButton.setDisable(false);
	    	spockButton.setDisable(false);
	    });
	    
	    scissorButton.setOnAction(e -> {
	    	clientConnection.gameData.p1Plays = "scissor";
	    	rockButton.setDisable(false);
	    	paperButton.setDisable(false);
	    	scissorButton.setDisable(true);
	    	lizardButton.setDisable(false);
	    	spockButton.setDisable(false);
	    });
	    
	    lizardButton.setOnAction(e -> {
	    	clientConnection.gameData.p1Plays = "lizard";
	    	rockButton.setDisable(false);
	    	paperButton.setDisable(false);
	    	scissorButton.setDisable(false);
	    	lizardButton.setDisable(true);
	    	spockButton.setDisable(false);
	    });
	    
	    spockButton.setOnAction(e -> {
	    	clientConnection.gameData.p1Plays = "spock";
	    	rockButton.setDisable(false);
	    	paperButton.setDisable(false);
	    	scissorButton.setDisable(false);
	    	lizardButton.setDisable(false);
	    	spockButton.setDisable(true);
	    });
	    
	    confirmButton.setOnAction(e ->{
	    	if(!clientConnection.gameData.p1Plays.equals("NULL")) {
					clientConnection.send((GameInfo)clientConnection.gameData);
					
	    		
	    	}
	    });
	    
	    
	    VBox playerButtons = new VBox(20);
	    playerButtons.getChildren().addAll(rockButton, paperButton, scissorButton, lizardButton, spockButton, confirmButton);
	    
	    /* VBOX containing all information of YOU */
	    VBox youInfo = new VBox(10);
	    youInfo.getChildren().addAll(youTitle, youPointsHBOX, playerButtons);
	    youInfo.setAlignment(Pos.TOP_CENTER);
	   
	    
	    // Opponent (PlayerTwo) Information ----------------------------------------------------------------
	    /* Title */
	    Text opponentTitle = new Text();
	    opponentTitle.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
	    opponentTitle.setFill(Color.WHITE);
		//title.setStroke(Color.AQUA);
	    opponentTitle.setText("Opponent");
	    
	    /* HBOX for player two Points */
	    Label opponentPointsLabel = new Label("Points: ");
	    opponentPointsLabel.setTextFill(Color.WHITE);
	    opponentPointsLabel.setFont(Font.font("verdana", 20));
	    opponentPointsDisplay = new TextField();
	    opponentPointsDisplay.setEditable(false); // Read Only Text Field
	    opponentPointsDisplay.setText("0");
	    HBox opponentPointsHBOX = new HBox(1);
	    listItems = new ListView();
	    opponentPointsHBOX.getChildren().addAll(opponentPointsLabel, opponentPointsDisplay, listItems);
	    
	    /* VBOX containing all information of YOU */
	    VBox opponentInfo = new VBox(10);
	    opponentInfo.getChildren().addAll(opponentTitle, opponentPointsHBOX);
	    opponentInfo.setAlignment(Pos.TOP_CENTER);
	    
	    
	    // Add/Modify borderPane -----------------------------------------------------------------------------
 		gamePane.setBackground(background); // Set the background loaded from the image
 		gamePane.setLeft(youInfo); // You info on the left
 		gamePane.setMargin(youInfo, new Insets(10));
 		gamePane.setRight(opponentInfo); // Opponent info on the right
 		gamePane.setMargin(opponentInfo, new Insets(10));
 		gamePane.setTop(menuBar);
 		
	    
	    gameScene = new Scene(gamePane, 1280, 720);
	    return gameScene;
	}
	

}
