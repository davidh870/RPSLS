import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.HashMap;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class ClientRPSLS extends Application {
	// Variables 
	static Stage window;
	Scene initialScene;
	static Scene gameScene;
	
	
	// Game Points Text Field
	static TextField playerOnePointsDisplay;
	static TextField playerTwoPointsDisplay;
	// Buttons For Game
	static Button rockButton;
	static Button paperButton;
	static Button scissorButton;
	static Button lizardButton;
	static Button spockButton;
	static Button confirmButton;
	
	// Connection Data
	static public Client clientConnection;
	static int portNum;
	static String ipAddress;
	
	static int whichPlayer;
	
	static ListView<String> listItems;
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	//feel free to remove the starter code from this method
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		window = primaryStage;
		window.setTitle("Initial Screen");
		
		initialScene = initialSceneCreate();
		window.setScene(initialScene);
		window.show();
	}
	
	
	public Scene initialSceneCreate() {
		Scene startScene; // Start Scene
		BorderPane startPane = new BorderPane();
		
		// BackGround ---------------------------------------------------------------------------------
		/* Load Image */
		Image imagebackground = new Image("bg.jpg", 1280, 720, false, false);
		/* Create a background from startBackground IMAGE */
	    Background background = new Background(new BackgroundImage(imagebackground, null, null, null, null));
	    
		
		// Title -------------------------------------------------------------------------------------------
		Text title = new Text();
		title.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
		title.setFill(Color.WHITE);
		//title.setStroke(Color.AQUA);
		title.setText("Rock! Paper! Scissor! Lizard! Spock!");
		
		// User Inputs in a HBOX ----------------------------------------------------------------------------
		/* IP Address */
		TextField ipAddressInput = new TextField();
		ipAddressInput.setPrefHeight(40); // Change size of textfield
		ipAddressInput.setFont(Font.font(20)); // Change font size for textfield
		ipAddressInput.setPromptText("Enter IP Address"); // Hint Text
		ipAddressInput.setFocusTraversable(false);
		/* Port */
		TextField portInput = new TextField();
		portInput.setPrefHeight(40); // Change size of textfield
		portInput.setFont(Font.font(20)); // Change font size for textfield
		portInput.setPromptText("Enter Port Number"); // Hint Text
		portInput.setFocusTraversable(false);
		/* Buttons */
		Button startButton = new Button("Start");
		startButton.setPrefSize(80, 40); // Change size of button
		startButton.setOnAction(e -> {
				gameScene = gameSceneCreate();
				
				// If port input and ip address text field is not empty then change scene and start a server
				if(!portInput.getText().trim().isEmpty() && !ipAddressInput.getText().trim().isEmpty()) {
					portNum = Integer.valueOf(portInput.getText());
					ipAddress = ipAddressInput.getText();
					
					clientConnection = new Client(data->{
						Platform.runLater(()->{listItems.getItems().add(data.toString());
										});
					});
						
					clientConnection.start();
					
					window.setTitle("Game Information");
					window.setScene(gameScene);
					window.show();
				}	
		}); 
		
		Button quitButton = new Button("Quit");
		quitButton.setPrefSize(80, 40); // Change size of button
		quitButton.setOnAction(e ->{
			Platform.exit();
			System.exit(0);
		});
		
		/* HBOX */
		HBox userInput = new HBox();
		userInput.getChildren().addAll(ipAddressInput, portInput, startButton, quitButton);
		userInput.setAlignment(Pos.CENTER);
		userInput.setMargin(portInput, new Insets(12));
		
		// Vbox for Center Border Pane -----------------------------------------------------------------------
		VBox centerVbox = new VBox();
		centerVbox.getChildren().addAll(title, userInput);
		centerVbox.setAlignment(Pos.CENTER);
		
		
		// Add/Modify borderPane -----------------------------------------------------------------------------
		startPane.setBackground(background); // Set the background loaded from the image
		startPane.setCenter(centerVbox);
		
		
		
		startScene = new Scene(startPane, 1280, 720); // Initial Scene
		
		return startScene; // Return Scene
		
	}
	
	public static Scene gameSceneCreate() {
		Scene gameScene; // Start Scene
		BorderPane gamePane = new BorderPane();
		
		// Menu Bar ---------------------------------------------------------------------------------------------------
		MenuBar menuBar = new MenuBar();
		Menu menuOne = new Menu("Options");
		
		MenuItem quitMenu = new MenuItem("Quit");
		quitMenu.setOnAction(e -> {
			Platform.exit();
			System.exit(0);
		});
		
		menuOne.getItems().add(quitMenu);
		menuBar.getMenus().add(menuOne);
		
		// BackGround ---------------------------------------------------------------------------------
		/* Load Image */
		Image imagebackground = new Image("bg.jpg", 1280, 720, false, false);
		/* Create a background from startBackground IMAGE */
	    Background background = new Background(new BackgroundImage(imagebackground, null, null, null, null));
	    
	    // PlayerOne Information ----------------------------------------------------------------
	    /* Title */
	    Text playerOneTitle = new Text();
	    playerOneTitle.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
	    playerOneTitle.setFill(Color.WHITE);
		//title.setStroke(Color.AQUA);
	    playerOneTitle.setText("Player One");
	    
	    /* HBOX for player one Points */
	    Label playerOnePointsLabel = new Label("Points: ");
	    playerOnePointsLabel.setTextFill(Color.WHITE);
	    playerOnePointsLabel.setFont(Font.font("verdana", 20));
	    playerOnePointsDisplay = new TextField();
	    playerOnePointsDisplay.setEditable(false); // Read Only Text Field
	    playerOnePointsDisplay.setText("0");
	    HBox playerOnePointsHBOX = new HBox(1);
	    playerOnePointsHBOX.getChildren().addAll(playerOnePointsLabel, playerOnePointsDisplay);
	    
	    /* Buttons to select which fighter you choose */
	    rockButton = new Button("Rock");
	    rockButton.setPrefSize(100, 10);
	    rockButton.setDisable(true);
	    
	    paperButton = new Button("Paper");
	    paperButton.setPrefSize(100, 10);
	    paperButton.setDisable(true);
	    
	    scissorButton = new Button("Scissor");
	    scissorButton.setPrefSize(100, 10);
	    scissorButton.setDisable(true);
	    
	    lizardButton = new Button("Lizard");
	    lizardButton.setPrefSize(100, 10);
	    lizardButton.setDisable(true);
	    
	    spockButton = new Button("Spock");
	    spockButton.setPrefSize(100, 10);
	    spockButton.setDisable(true);
	    
	    confirmButton = new Button("Confirm");
	    confirmButton.setPrefSize(100, 10);
	    confirmButton.setDisable(true);
	    
	    rockButton.setOnAction(e -> {
	    	if(whichPlayer == 1) {
	    		clientConnection.gameData.p1Plays = "rock";
	    	}
	    	else {
	    		clientConnection.gameData.p2Plays = "rock";
	    	}
	    	
	    	rockButton.setDisable(true);
	    	paperButton.setDisable(false);
	    	scissorButton.setDisable(false);
	    	lizardButton.setDisable(false);
	    	spockButton.setDisable(false);
	    });
	    

	    paperButton.setOnAction(e -> {
	    	if(whichPlayer == 1) {
	    		clientConnection.gameData.p1Plays = "paper";
	    	}
	    	else {
	    		clientConnection.gameData.p2Plays = "paper";
	    	}
	    	rockButton.setDisable(false);
	    	paperButton.setDisable(true);
	    	scissorButton.setDisable(false);
	    	lizardButton.setDisable(false);
	    	spockButton.setDisable(false);
	    });
	    
	    scissorButton.setOnAction(e -> {
	    	if(whichPlayer == 1) {
	    		clientConnection.gameData.p1Plays = "scissor";
	    	}
	    	else {
	    		clientConnection.gameData.p2Plays = "scissor";
	    	}
	    	rockButton.setDisable(false);
	    	paperButton.setDisable(false);
	    	scissorButton.setDisable(true);
	    	lizardButton.setDisable(false);
	    	spockButton.setDisable(false);
	    });
	    
	    lizardButton.setOnAction(e -> {
	    	if(whichPlayer == 1) {
	    		clientConnection.gameData.p1Plays = "lizard";
	    	}
	    	else {
	    		clientConnection.gameData.p2Plays = "lizard";
	    	}
	    	rockButton.setDisable(false);
	    	paperButton.setDisable(false);
	    	scissorButton.setDisable(false);
	    	lizardButton.setDisable(true);
	    	spockButton.setDisable(false);
	    });
	    
	    spockButton.setOnAction(e -> {
	    	if(whichPlayer == 1) {
	    		clientConnection.gameData.p1Plays = "spock";
	    	}
	    	else {
	    		clientConnection.gameData.p2Plays = "spock";
	    	}
	    	rockButton.setDisable(false);
	    	paperButton.setDisable(false);
	    	scissorButton.setDisable(false);
	    	lizardButton.setDisable(false);
	    	spockButton.setDisable(true);
	    });
	    
	    confirmButton.setOnAction(e ->{
	    	if(whichPlayer == 1) {
	    		if(!clientConnection.gameData.p1Plays.equals("NULL")) {
					clientConnection.send((GameInfo)clientConnection.gameData);
					
					rockButton.setDisable(true);
					paperButton.setDisable(true);
					scissorButton.setDisable(true);
					lizardButton.setDisable(true);
					spockButton.setDisable(true);
					confirmButton.setDisable(true);
	    	
	    		}
	    		else {
		    		listItems.getItems().add("Please Choose A Fighter");
		    	}
	    	}
	    	else{
	    		if(!clientConnection.gameData.p2Plays.equals("NULL")) {
					clientConnection.send((GameInfo)clientConnection.gameData);
					
					rockButton.setDisable(true);
					paperButton.setDisable(true);
					scissorButton.setDisable(true);
					lizardButton.setDisable(true);
					spockButton.setDisable(true);
					confirmButton.setDisable(true);
	    	
	    		}
	    		else {
		    		listItems.getItems().add("Please Choose A Fighter");
		    	}
	    	}
					
	    });
	    
	    
	    VBox playerButtons = new VBox(20);
	    playerButtons.getChildren().addAll(rockButton, paperButton, scissorButton, lizardButton, spockButton, confirmButton);
	    
	    /* VBOX containing all information of YOU */
	    VBox playerOneInfo = new VBox(10);
	    playerOneInfo.getChildren().addAll(playerOneTitle, playerOnePointsHBOX, playerButtons);
	    playerOneInfo.setAlignment(Pos.TOP_CENTER);
	   
	    
	    //  PlayerTwo Information ----------------------------------------------------------------
	    /* Title */
	    Text playerTwoTitle = new Text();
	    playerTwoTitle.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
	    playerTwoTitle.setFill(Color.WHITE);
		//title.setStroke(Color.AQUA);
	    playerTwoTitle.setText("Player Two");
	    
	    /* HBOX for player two Points */
	    Label playerTwoPointsLabel = new Label("Points: ");
	    playerTwoPointsLabel.setTextFill(Color.WHITE);
	    playerTwoPointsLabel.setFont(Font.font("verdana", 20));
	    playerTwoPointsDisplay = new TextField();
	    playerTwoPointsDisplay.setEditable(false); // Read Only Text Field
	    playerTwoPointsDisplay.setText("0");
	    HBox playerTwoPointsHBOX = new HBox(1);
	    listItems = new ListView();
	    playerTwoPointsHBOX.getChildren().addAll(playerTwoPointsLabel, playerTwoPointsDisplay, listItems);
	    
	    /* VBOX containing all information of YOU */
	    VBox playerTwoInfo = new VBox(10);
	    playerTwoInfo.getChildren().addAll(playerTwoTitle, playerTwoPointsHBOX);
	    playerTwoInfo.setAlignment(Pos.TOP_CENTER);
	    
	    
	    // Add/Modify borderPane -----------------------------------------------------------------------------
 		gamePane.setBackground(background); // Set the background loaded from the image
 		gamePane.setLeft(playerOneInfo); // You info on the left
 		gamePane.setMargin(playerOneInfo, new Insets(10));
 		gamePane.setRight(playerTwoInfo); // Opponent info on the right
 		gamePane.setMargin(playerTwoInfo, new Insets(10));
 		gamePane.setTop(menuBar);
 		
	    
	    gameScene = new Scene(gamePane, 1280, 720);
	    return gameScene;
	}
	

	
	
	static public Scene thirdSceneCreate() {
		Scene thirdScene;
		BorderPane thirdBP = new BorderPane();
		
		// BackGround ---------------------------------------------------------------------------------
		/* Load Image */
		Image imagebackground = new Image("bg.jpg", 1280, 720, false, false);
		/* Create a background from startBackground IMAGE */
	    Background background = new Background(new BackgroundImage(imagebackground, null, null, null, null));
	    
	    
	    //  User Input Buttons -------------------------------------------------------------------------------------
	    Button playAgainButton = new Button("Start");
		playAgainButton.setPrefSize(80, 40); // Change size of button
		playAgainButton.setOnAction(e -> {
				gameScene = gameSceneCreate();
				
				window.setTitle("Game Information");
				window.setScene(gameScene);
				window.show();
		}); 
		
		Button quitButton = new Button("Quit");
		quitButton.setPrefSize(80, 40); // Change size of button
		quitButton.setOnAction(e ->{
			Platform.exit();
			System.exit(0);
		});
	    
	    /* HBOX for all buttons */
		HBox playAgainHBox = new HBox(4);
		playAgainHBox.getChildren().addAll(playAgainButton, quitButton);
		
		
		// Modify / Add into BorderPane --------------------------------------------------------------------------
		thirdBP.setCenter(playAgainHBox);
		
		thirdScene = new Scene(thirdBP, 600, 800);
		return thirdScene;
	}
}
