import java.io.Serializable;

public class GameInfo implements  Serializable{
  public int p1Points;
  public int p2Points; 
  public String p1Plays;
  public String p2Plays;
  public String roundWon; 
  public String gameWon;
  


  // Parametized constructor
  public GameInfo(int pointsP1, int pointsP2, String playsP1, String playsP2, String roundwon, String gamewon) {
    this.p1Points = pointsP1;
    this.p2Points = pointsP2;
    this.p1Plays = playsP1;
    this.p2Plays = playsP2;
    this.roundWon = roundwon;
    this.gameWon = gamewon;
  }

 
}